window.SYLLABUS_DATA = [
  {
    "subjectId": 1000109,
    "name": "Anatomy",
    "questionCount": 1679,
    "moduleCount": 58,
    "modules": [
      {
        "id": 1,
        "moduleId": "m0",
        "name": "Gametogenesis",
        "section": "Embryology",
        "questionCount": 4
      },
      {
        "id": 2,
        "moduleId": "m1",
        "name": "Pre-Embryonic Phase of Development",
        "section": "Embryology",
        "questionCount": 82
      },
      {
        "id": 3,
        "moduleId": "m2",
        "name": "Embryonic Phase of Development",
        "section": "Embryology",
        "questionCount": 7
      },
      {
        "id": 4,
        "moduleId": "m3",
        "name": "Placenta, Fetal Membranes and Twinning",
        "section": "Embryology",
        "questionCount": 11
      },
      {
        "id": 5,
        "moduleId": "m4",
        "name": "Pharyngeal Arches, Skeletal & Muscular Systems",
        "section": "Embryology",
        "questionCount": 29
      },
      {
        "id": 6,
        "moduleId": "m5",
        "name": "Cardiovascular and Respiratory Systems",
        "section": "Embryology",
        "questionCount": 28
      },
      {
        "id": 7,
        "moduleId": "m6",
        "name": "Alimentary, Hepatobiliary Systems, Pancreas and Spleen",
        "section": "Embryology",
        "questionCount": 11
      },
      {
        "id": 8,
        "moduleId": "m7",
        "name": "Face, Nose & Palate, Eye, Ear",
        "section": "Embryology",
        "questionCount": 18
      },
      {
        "id": 9,
        "moduleId": "m8",
        "name": "Nervous System and Endocrine Glands",
        "section": "Embryology",
        "questionCount": 20
      },
      {
        "id": 10,
        "moduleId": "m9",
        "name": "Cell Structure, Epithelia, Glands & Connective Tissue",
        "section": "Histology",
        "questionCount": 153
      },
      {
        "id": 11,
        "moduleId": "m10",
        "name": "Bone, Cartilage & Muscular Tissue",
        "section": "Histology",
        "questionCount": 27
      },
      {
        "id": 12,
        "moduleId": "m11",
        "name": "Cardiovascular, Lymphatic and Respiratory Systems",
        "section": "Histology",
        "questionCount": 3
      },
      {
        "id": 13,
        "moduleId": "m12",
        "name": "Digestive, Hepatobiliary & Genitourinary Systems",
        "section": "Histology",
        "questionCount": 2
      },
      {
        "id": 14,
        "moduleId": "m13",
        "name": "Cranial Nerves",
        "section": "Neuroanatomy",
        "questionCount": 28
      },
      {
        "id": 15,
        "moduleId": "m14",
        "name": "Meninges and Dural Venous Sinuses",
        "section": "Neuroanatomy",
        "questionCount": 12
      },
      {
        "id": 16,
        "moduleId": "m15",
        "name": "Ventricular System and Subarachnoid Space",
        "section": "Neuroanatomy",
        "questionCount": 11
      },
      {
        "id": 17,
        "moduleId": "m16",
        "name": "Cerebrum",
        "section": "Neuroanatomy",
        "questionCount": 11
      },
      {
        "id": 18,
        "moduleId": "m17",
        "name": "White Matter of the Brain",
        "section": "Neuroanatomy",
        "questionCount": 5
      },
      {
        "id": 19,
        "moduleId": "m18",
        "name": "Basal Ganglia and Limbic System",
        "section": "Neuroanatomy",
        "questionCount": 6
      },
      {
        "id": 20,
        "moduleId": "m19",
        "name": "Diencephalon",
        "section": "Neuroanatomy",
        "questionCount": 16
      },
      {
        "id": 21,
        "moduleId": "m20",
        "name": "Brainstem",
        "section": "Neuroanatomy",
        "questionCount": 20
      },
      {
        "id": 22,
        "moduleId": "m21",
        "name": "Cerebellum",
        "section": "Neuroanatomy",
        "questionCount": 25
      },
      {
        "id": 23,
        "moduleId": "m22",
        "name": "Vascular Supply of Brain",
        "section": "Neuroanatomy",
        "questionCount": 15
      },
      {
        "id": 24,
        "moduleId": "m23",
        "name": "Spinal Cord",
        "section": "Neuroanatomy",
        "questionCount": 36
      },
      {
        "id": 25,
        "moduleId": "m24",
        "name": "Osteology, Scalp and Face",
        "section": "Head and Neck",
        "questionCount": 10
      },
      {
        "id": 26,
        "moduleId": "m25",
        "name": "Deep Fascia and Triangles of the Neck",
        "section": "Head and Neck",
        "questionCount": 14
      },
      {
        "id": 27,
        "moduleId": "m26",
        "name": "Muscles, Neurovascular Anatomy of Head & Neck",
        "section": "Head and Neck",
        "questionCount": 216
      },
      {
        "id": 28,
        "moduleId": "m27",
        "name": "Glands of the Head & Neck",
        "section": "Head and Neck",
        "questionCount": 0
      },
      {
        "id": 29,
        "moduleId": "m28",
        "name": "Tongue and Palate",
        "section": "Head and Neck",
        "questionCount": 5
      },
      {
        "id": 30,
        "moduleId": "m29",
        "name": "Pharynx",
        "section": "Head and Neck",
        "questionCount": 33
      },
      {
        "id": 31,
        "moduleId": "m30",
        "name": "Upper Limb Bones and Joints",
        "section": "Upper Limb",
        "questionCount": 65
      },
      {
        "id": 32,
        "moduleId": "m31",
        "name": "Fossae and Spaces of the Upper Limb",
        "section": "Upper Limb",
        "questionCount": 6
      },
      {
        "id": 33,
        "moduleId": "m32",
        "name": "Brachial Plexus and Nerves",
        "section": "Upper Limb",
        "questionCount": 25
      },
      {
        "id": 34,
        "moduleId": "m33",
        "name": "Muscles - Upper Limb",
        "section": "Upper Limb",
        "questionCount": 30
      },
      {
        "id": 35,
        "moduleId": "m34",
        "name": "Vessels - Upper Limb",
        "section": "Upper Limb",
        "questionCount": 13
      },
      {
        "id": 36,
        "moduleId": "m35",
        "name": "General Anatomy of Thorax",
        "section": "Thorax",
        "questionCount": 45
      },
      {
        "id": 37,
        "moduleId": "m36",
        "name": "Thoracic Wall",
        "section": "Thorax",
        "questionCount": 30
      },
      {
        "id": 38,
        "moduleId": "m37",
        "name": "Mediastinum",
        "section": "Thorax",
        "questionCount": 23
      },
      {
        "id": 39,
        "moduleId": "m38",
        "name": "Heart",
        "section": "Thorax",
        "questionCount": 81
      },
      {
        "id": 40,
        "moduleId": "m39",
        "name": "Lungs and Pleura",
        "section": "Thorax",
        "questionCount": 27
      },
      {
        "id": 41,
        "moduleId": "m40",
        "name": "Anterior Abdominal Wall",
        "section": "Abdomen and Pelvis",
        "questionCount": 78
      },
      {
        "id": 42,
        "moduleId": "m41",
        "name": "Abdominal Cavity and Peritoneum",
        "section": "Abdomen and Pelvis",
        "questionCount": 16
      },
      {
        "id": 43,
        "moduleId": "m42",
        "name": "GI Tract",
        "section": "Abdomen and Pelvis",
        "questionCount": 22
      },
      {
        "id": 44,
        "moduleId": "m43",
        "name": "Hepatobiliary System, Spleen & Pancreas",
        "section": "Abdomen and Pelvis",
        "questionCount": 16
      },
      {
        "id": 45,
        "moduleId": "m44",
        "name": "KUB & Adrenal Gland",
        "section": "Abdomen and Pelvis",
        "questionCount": 29
      },
      {
        "id": 46,
        "moduleId": "m45",
        "name": "Internal and External Genitalia",
        "section": "Abdomen and Pelvis",
        "questionCount": 31
      },
      {
        "id": 47,
        "moduleId": "m46",
        "name": "Pelvis & Perineum",
        "section": "Abdomen and Pelvis",
        "questionCount": 29
      },
      {
        "id": 48,
        "moduleId": "m47",
        "name": "Bones of the Lower Limb",
        "section": "Lower Limb",
        "questionCount": 49
      },
      {
        "id": 49,
        "moduleId": "m48",
        "name": "Joints of the Lower Limb",
        "section": "Lower Limb",
        "questionCount": 3
      },
      {
        "id": 50,
        "moduleId": "m49",
        "name": "Muscles of the Lower Limb",
        "section": "Lower Limb",
        "questionCount": 32
      },
      {
        "id": 51,
        "moduleId": "m50",
        "name": "Nerves & Vessels of Lower Limb",
        "section": "Lower Limb",
        "questionCount": 16
      },
      {
        "id": 52,
        "moduleId": "m51",
        "name": "Important Structures of Lower Limb",
        "section": "Lower Limb",
        "questionCount": 23
      },
      {
        "id": 53,
        "moduleId": "m52",
        "name": "Vertebral Column",
        "section": "Lower Limb",
        "questionCount": 31
      },
      {
        "id": 54,
        "moduleId": "m53",
        "name": "Bones, Joints and Cartilage",
        "section": "General Anatomy",
        "questionCount": 48
      },
      {
        "id": 55,
        "moduleId": "m54",
        "name": "Muscles and Tendons",
        "section": "General Anatomy",
        "questionCount": 28
      },
      {
        "id": 56,
        "moduleId": "m55",
        "name": "Cardiovascular, Lymphatic and Nervous Systems",
        "section": "General Anatomy",
        "questionCount": 4
      },
      {
        "id": 57,
        "moduleId": "m56",
        "name": "Skin, Connective Tissue and Ligaments",
        "section": "General Anatomy",
        "questionCount": 19
      },
      {
        "id": 58,
        "moduleId": "m57",
        "name": "Mixed / Miscellaneous Topics",
        "section": "General Anatomy",
        "questionCount": 2
      }
    ]
  },
  {
    "subjectId": 1000110,
    "name": "Physiology",
    "questionCount": 1641,
    "moduleCount": 40,
    "modules": [
      {
        "id": 59,
        "moduleId": "m0",
        "name": "Homeostasis and Cellular Physiology",
        "section": "General Physiology",
        "questionCount": 62
      },
      {
        "id": 60,
        "moduleId": "m1",
        "name": "Cellular Messengers & Receptors",
        "section": "General Physiology",
        "questionCount": 32
      },
      {
        "id": 61,
        "moduleId": "m2",
        "name": "Transport Across Cell Membrane",
        "section": "General Physiology",
        "questionCount": 80
      },
      {
        "id": 62,
        "moduleId": "m3",
        "name": "Membrane Potentials",
        "section": "General Physiology",
        "questionCount": 38
      },
      {
        "id": 63,
        "moduleId": "m4",
        "name": "Body Fluids",
        "section": "General Physiology",
        "questionCount": 57
      },
      {
        "id": 64,
        "moduleId": "m5",
        "name": "Physiology of Nerve",
        "section": "Nerve Muscle Physiology",
        "questionCount": 45
      },
      {
        "id": 65,
        "moduleId": "m6",
        "name": "Muscle Physiology I",
        "section": "Nerve Muscle Physiology",
        "questionCount": 68
      },
      {
        "id": 66,
        "moduleId": "m7",
        "name": "Synapse and Junctional Transmission",
        "section": "Nerve Muscle Physiology",
        "questionCount": 5
      },
      {
        "id": 67,
        "moduleId": "m8",
        "name": "Neurotransmitters",
        "section": "Central Nervous System",
        "questionCount": 20
      },
      {
        "id": 68,
        "moduleId": "m9",
        "name": "Sensory Receptors",
        "section": "Central Nervous System",
        "questionCount": 35
      },
      {
        "id": 69,
        "moduleId": "m10",
        "name": "Somatosensory Pathways",
        "section": "Central Nervous System",
        "questionCount": 12
      },
      {
        "id": 70,
        "moduleId": "m11",
        "name": "Special Senses",
        "section": "Central Nervous System",
        "questionCount": 23
      },
      {
        "id": 71,
        "moduleId": "m12",
        "name": "Motor Physiology - 1",
        "section": "Central Nervous System",
        "questionCount": 51
      },
      {
        "id": 72,
        "moduleId": "m13",
        "name": "Basal Ganglia and Cerebellum",
        "section": "Central Nervous System",
        "questionCount": 20
      },
      {
        "id": 73,
        "moduleId": "m14",
        "name": "Hypothalamus and Limbic System",
        "section": "Central Nervous System",
        "questionCount": 32
      },
      {
        "id": 74,
        "moduleId": "m15",
        "name": "Higher Mental Functions",
        "section": "Central Nervous System",
        "questionCount": 20
      },
      {
        "id": 75,
        "moduleId": "m16",
        "name": "Functional Anatomy",
        "section": "The Respiratory System",
        "questionCount": 7
      },
      {
        "id": 76,
        "moduleId": "m17",
        "name": "Lung Mechanics",
        "section": "The Respiratory System",
        "questionCount": 12
      },
      {
        "id": 77,
        "moduleId": "m18",
        "name": "Alveolar Gas Exchange",
        "section": "The Respiratory System",
        "questionCount": 22
      },
      {
        "id": 78,
        "moduleId": "m19",
        "name": "Gas Transport in Blood",
        "section": "The Respiratory System",
        "questionCount": 50
      },
      {
        "id": 79,
        "moduleId": "m20",
        "name": "Lung Volumes and Lung Function Tests",
        "section": "The Respiratory System",
        "questionCount": 69
      },
      {
        "id": 80,
        "moduleId": "m21",
        "name": "Respiratory Adaptations in Hypoxia, Anemia and with Pressure Changes",
        "section": "The Respiratory System",
        "questionCount": 72
      },
      {
        "id": 81,
        "moduleId": "m22",
        "name": "Regulation of Respiration",
        "section": "The Respiratory System",
        "questionCount": 6
      },
      {
        "id": 82,
        "moduleId": "m23",
        "name": "Vascular System and Regional Circulation I",
        "section": "The Cardiovascular System",
        "questionCount": 15
      },
      {
        "id": 83,
        "moduleId": "m24",
        "name": "Cardiac Cycle and Cardiac Output",
        "section": "The Cardiovascular System",
        "questionCount": 70
      },
      {
        "id": 84,
        "moduleId": "m25",
        "name": "Electrophysiology of the Heart",
        "section": "The Cardiovascular System",
        "questionCount": 15
      },
      {
        "id": 85,
        "moduleId": "m26",
        "name": "Blood Pressure and Regulation",
        "section": "The Cardiovascular System",
        "questionCount": 88
      },
      {
        "id": 86,
        "moduleId": "m27",
        "name": "Gastrointestinal Secretion and Gastrointestinal Hormones",
        "section": "The Gastrointestinal Tract",
        "questionCount": 51
      },
      {
        "id": 87,
        "moduleId": "m28",
        "name": "Digestion & Absorption",
        "section": "The Gastrointestinal Tract",
        "questionCount": 43
      },
      {
        "id": 88,
        "moduleId": "m29",
        "name": "GI Peristalsis and Motility",
        "section": "The Gastrointestinal Tract",
        "questionCount": 36
      },
      {
        "id": 89,
        "moduleId": "m30",
        "name": "Glomerular Filtration Rate, Renal Blood Flow, and Renal Clearance",
        "section": "Renal Physiology",
        "questionCount": 75
      },
      {
        "id": 90,
        "moduleId": "m31",
        "name": "Renal Tubular Functions, Urine Concentration and Dilution",
        "section": "Renal Physiology",
        "questionCount": 24
      },
      {
        "id": 91,
        "moduleId": "m32",
        "name": "Acid-Base Balance, Renal Hormones and Micturition Reflex",
        "section": "Renal Physiology",
        "questionCount": 61
      },
      {
        "id": 92,
        "moduleId": "m33",
        "name": "Pituitary and Thyroid",
        "section": "Endocrine Physiology",
        "questionCount": 110
      },
      {
        "id": 93,
        "moduleId": "m34",
        "name": "The Pancreas",
        "section": "Endocrine Physiology",
        "questionCount": 9
      },
      {
        "id": 94,
        "moduleId": "m35",
        "name": "Calcium Homeostasis",
        "section": "Endocrine Physiology",
        "questionCount": 11
      },
      {
        "id": 95,
        "moduleId": "m36",
        "name": "Male Reproductive Physiology",
        "section": "Reproductive Physiology",
        "questionCount": 35
      },
      {
        "id": 96,
        "moduleId": "m37",
        "name": "Female Reproductive Physiology",
        "section": "Reproductive Physiology",
        "questionCount": 11
      },
      {
        "id": 97,
        "moduleId": "m38",
        "name": "Exercise Physiology",
        "section": "Exercise Physiology",
        "questionCount": 12
      },
      {
        "id": 98,
        "moduleId": "m39",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Exercise Physiology",
        "questionCount": 137
      }
    ]
  },
  {
    "subjectId": 1000187,
    "name": "Biochemistry",
    "questionCount": 1516,
    "moduleCount": 27,
    "modules": [
      {
        "id": 99,
        "moduleId": "m0",
        "name": "Chemistry of Carbohydrates, Amino Sugars and Mucopolysaccharides",
        "section": "Carbohydrates",
        "questionCount": 23
      },
      {
        "id": 100,
        "moduleId": "m1",
        "name": "Glycolysis and Gluconeogenesis",
        "section": "Carbohydrates",
        "questionCount": 39
      },
      {
        "id": 101,
        "moduleId": "m2",
        "name": "Glycogen Metabolism and Glycogen Storage Disorders",
        "section": "Carbohydrates",
        "questionCount": 134
      },
      {
        "id": 102,
        "moduleId": "m3",
        "name": "HMP Shunt Pathway, Fructose, Galactose Metabolism",
        "section": "Carbohydrates",
        "questionCount": 57
      },
      {
        "id": 103,
        "moduleId": "m4",
        "name": "Krebs Cycle",
        "section": "Carbohydrates",
        "questionCount": 11
      },
      {
        "id": 104,
        "moduleId": "m5",
        "name": "Amino Acids: Basics",
        "section": "Amino Acids and Proteins",
        "questionCount": 52
      },
      {
        "id": 105,
        "moduleId": "m6",
        "name": "Amino Acid: Metabolism",
        "section": "Amino Acids and Proteins",
        "questionCount": 32
      },
      {
        "id": 106,
        "moduleId": "m7",
        "name": "Amino Acid: Metabolic Disorder",
        "section": "Amino Acids and Proteins",
        "questionCount": 75
      },
      {
        "id": 107,
        "moduleId": "m8",
        "name": "Protein Structure and Function",
        "section": "Amino Acids and Proteins",
        "questionCount": 269
      },
      {
        "id": 108,
        "moduleId": "m9",
        "name": "Urea Cycle and its Disorders",
        "section": "Amino Acids and Proteins",
        "questionCount": 23
      },
      {
        "id": 109,
        "moduleId": "m10",
        "name": "Lipids: Basics",
        "section": "Lipids",
        "questionCount": 19
      },
      {
        "id": 110,
        "moduleId": "m11",
        "name": "Fatty Acid Oxidation and Ketogenesis",
        "section": "Lipids",
        "questionCount": 69
      },
      {
        "id": 111,
        "moduleId": "m12",
        "name": "Biosynthesis of Fatty Acids and Eicosanoids",
        "section": "Lipids",
        "questionCount": 6
      },
      {
        "id": 112,
        "moduleId": "m13",
        "name": "Metabolism of Acylglycerols and Sphingolipids",
        "section": "Lipids",
        "questionCount": 17
      },
      {
        "id": 113,
        "moduleId": "m14",
        "name": "Cholesterol Synthesis, Transport and Excretion",
        "section": "Lipids",
        "questionCount": 86
      },
      {
        "id": 114,
        "moduleId": "m15",
        "name": "Porphyrins and Bile Pigments",
        "section": "Enzymes and Porphyrins",
        "questionCount": 6
      },
      {
        "id": 115,
        "moduleId": "m16",
        "name": "Enzymes - Mechanism of Action & Clinical Importance",
        "section": "Enzymes and Porphyrins",
        "questionCount": 159
      },
      {
        "id": 116,
        "moduleId": "m17",
        "name": "Enzyme Kinetics and Regulation of Activity",
        "section": "Enzymes and Porphyrins",
        "questionCount": 92
      },
      {
        "id": 117,
        "moduleId": "m18",
        "name": "Fat Soluble Vitamins",
        "section": "Clinical Biochemistry & Nutrition",
        "questionCount": 72
      },
      {
        "id": 118,
        "moduleId": "m19",
        "name": "Energy Releasing Vitamins",
        "section": "Clinical Biochemistry & Nutrition",
        "questionCount": 43
      },
      {
        "id": 119,
        "moduleId": "m20",
        "name": "Antioxidants & Minerals",
        "section": "Clinical Biochemistry & Nutrition",
        "questionCount": 31
      },
      {
        "id": 120,
        "moduleId": "m21",
        "name": "Basics of Genetics - Nucleotide Metabolism and its Disorders",
        "section": "Genetics",
        "questionCount": 33
      },
      {
        "id": 121,
        "moduleId": "m22",
        "name": "DNA Organization, Replication and Repair",
        "section": "Genetics",
        "questionCount": 29
      },
      {
        "id": 122,
        "moduleId": "m23",
        "name": "RNA Synthesis, Processing and Modification",
        "section": "Genetics",
        "questionCount": 22
      },
      {
        "id": 123,
        "moduleId": "m24",
        "name": "Regulation of Gene Expression",
        "section": "Genetics",
        "questionCount": 29
      },
      {
        "id": 124,
        "moduleId": "m25",
        "name": "Molecular Genetics, Recombinant DNA & Genomic Technology",
        "section": "Genetics",
        "questionCount": 16
      },
      {
        "id": 125,
        "moduleId": "m26",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Genetics",
        "questionCount": 72
      }
    ]
  },
  {
    "subjectId": 1000112,
    "name": "Pathology",
    "questionCount": 1664,
    "moduleCount": 64,
    "modules": [
      {
        "id": 126,
        "moduleId": "m0",
        "name": "Cellular Adaptations and Injury",
        "section": "General Pathology",
        "questionCount": 42
      },
      {
        "id": 127,
        "moduleId": "m1",
        "name": "Cell Death",
        "section": "General Pathology",
        "questionCount": 86
      },
      {
        "id": 128,
        "moduleId": "m2",
        "name": "Intracellular Accumulations, Pathological Calcification and Cellular Ageing",
        "section": "General Pathology",
        "questionCount": 121
      },
      {
        "id": 129,
        "moduleId": "m3",
        "name": "Acute Inflammation",
        "section": "General Pathology",
        "questionCount": 52
      },
      {
        "id": 130,
        "moduleId": "m4",
        "name": "Inflammatory Mediators and Chronic Granulomatous Inflammation",
        "section": "General Pathology",
        "questionCount": 128
      },
      {
        "id": 131,
        "moduleId": "m5",
        "name": "Tissue Repair",
        "section": "General Pathology",
        "questionCount": 19
      },
      {
        "id": 132,
        "moduleId": "m6",
        "name": "Disorders of Hemodynamics and Hemostasis",
        "section": "General Pathology",
        "questionCount": 8
      },
      {
        "id": 133,
        "moduleId": "m7",
        "name": "Modes of Inheritance",
        "section": "General Pathology",
        "questionCount": 19
      },
      {
        "id": 134,
        "moduleId": "m8",
        "name": "Lysosomal and Glycogen Storage Diseases",
        "section": "General Pathology",
        "questionCount": 57
      },
      {
        "id": 135,
        "moduleId": "m9",
        "name": "Chromosomal Disorders and Other Genetic Diseases",
        "section": "General Pathology",
        "questionCount": 78
      },
      {
        "id": 136,
        "moduleId": "m10",
        "name": "Characteristics of Neoplasms and Epidemiology",
        "section": "General Pathology",
        "questionCount": 14
      },
      {
        "id": 137,
        "moduleId": "m11",
        "name": "Molecular Basis of Cancer and Tumor Immunity",
        "section": "General Pathology",
        "questionCount": 84
      },
      {
        "id": 138,
        "moduleId": "m12",
        "name": "Carcinogenesis, Paraneoplastic Syndromes and Tumor Markers",
        "section": "General Pathology",
        "questionCount": 10
      },
      {
        "id": 139,
        "moduleId": "m13",
        "name": "Components of Immune System",
        "section": "General Pathology",
        "questionCount": 19
      },
      {
        "id": 140,
        "moduleId": "m14",
        "name": "Hypersensitivity and Autoimmunity",
        "section": "General Pathology",
        "questionCount": 7
      },
      {
        "id": 141,
        "moduleId": "m15",
        "name": "Amyloidosis and Graft Rejection",
        "section": "General Pathology",
        "questionCount": 12
      },
      {
        "id": 142,
        "moduleId": "m16",
        "name": "Microcytic Anemia",
        "section": "Hematology",
        "questionCount": 15
      },
      {
        "id": 143,
        "moduleId": "m17",
        "name": "Normocytic And Macrocytic Anemia",
        "section": "Hematology",
        "questionCount": 5
      },
      {
        "id": 144,
        "moduleId": "m18",
        "name": "Basics of Hemolysis and Intravascular Hemolysis",
        "section": "Hematology",
        "questionCount": 20
      },
      {
        "id": 145,
        "moduleId": "m19",
        "name": "Extravascular Hemolysis",
        "section": "Hematology",
        "questionCount": 9
      },
      {
        "id": 146,
        "moduleId": "m20",
        "name": "G6PD Deficiency and Autoimmune Hemolytic Anemias",
        "section": "Hematology",
        "questionCount": 34
      },
      {
        "id": 147,
        "moduleId": "m21",
        "name": "Platelet Disorders",
        "section": "Hematology",
        "questionCount": 33
      },
      {
        "id": 148,
        "moduleId": "m22",
        "name": "Coagulation Pathway Disorders",
        "section": "Hematology",
        "questionCount": 23
      },
      {
        "id": 149,
        "moduleId": "m23",
        "name": "Blood Products and Transfusion Reactions",
        "section": "Hematology",
        "questionCount": 35
      },
      {
        "id": 150,
        "moduleId": "m24",
        "name": "Acute Lymphocytic Leukemia (ALL)",
        "section": "Hematology",
        "questionCount": 28
      },
      {
        "id": 151,
        "moduleId": "m25",
        "name": "Acute Myeloid Leukemia (AML)",
        "section": "Hematology",
        "questionCount": 16
      },
      {
        "id": 152,
        "moduleId": "m26",
        "name": "Hodgkin's Lymphoma",
        "section": "Hematology",
        "questionCount": 25
      },
      {
        "id": 153,
        "moduleId": "m27",
        "name": "Non Hodgkin Lymphomas: Low Grade",
        "section": "Hematology",
        "questionCount": 12
      },
      {
        "id": 154,
        "moduleId": "m28",
        "name": "Non Hodgkin Lymphomas: High Grade",
        "section": "Hematology",
        "questionCount": 5
      },
      {
        "id": 155,
        "moduleId": "m29",
        "name": "Multiple Myeloma and Plasma Cell Disorders",
        "section": "Hematology",
        "questionCount": 58
      },
      {
        "id": 156,
        "moduleId": "m30",
        "name": "Myelodysplastic Syndrome, Myeloproliferative Neoplasms and Histiocytosis",
        "section": "Hematology",
        "questionCount": 35
      },
      {
        "id": 157,
        "moduleId": "m31",
        "name": "Leukemoid, Leukocytosis and Lymphadenitis",
        "section": "Hematology",
        "questionCount": 2
      },
      {
        "id": 158,
        "moduleId": "m32",
        "name": "Hypertensive Vascular Disease and Atherosclerosis",
        "section": "Cardiovascular System",
        "questionCount": 81
      },
      {
        "id": 159,
        "moduleId": "m33",
        "name": "Aneurysm and Dissection",
        "section": "Cardiovascular System",
        "questionCount": 9
      },
      {
        "id": 160,
        "moduleId": "m34",
        "name": "Vascular Tumors",
        "section": "Cardiovascular System",
        "questionCount": 6
      },
      {
        "id": 161,
        "moduleId": "m35",
        "name": "Heart Failure and Ischemic Heart Disease",
        "section": "Cardiovascular System",
        "questionCount": 39
      },
      {
        "id": 162,
        "moduleId": "m36",
        "name": "Myocardial and Pericardial Diseases and Cardiac Tumors",
        "section": "Cardiovascular System",
        "questionCount": 23
      },
      {
        "id": 163,
        "moduleId": "m37",
        "name": "Congenital and Valvular Heart Disease",
        "section": "Cardiovascular System",
        "questionCount": 4
      },
      {
        "id": 164,
        "moduleId": "m38",
        "name": "Rheumatic Fever and Endocarditis",
        "section": "Cardiovascular System",
        "questionCount": 5
      },
      {
        "id": 165,
        "moduleId": "m39",
        "name": "Glomerular Diseases",
        "section": "Genitourinary System",
        "questionCount": 8
      },
      {
        "id": 166,
        "moduleId": "m40",
        "name": "Tubulointerstitial, Vascular and Cystic Diseases",
        "section": "Genitourinary System",
        "questionCount": 7
      },
      {
        "id": 167,
        "moduleId": "m41",
        "name": "Renal Tumors",
        "section": "Genitourinary System",
        "questionCount": 7
      },
      {
        "id": 168,
        "moduleId": "m42",
        "name": "Lower Urinary Tract",
        "section": "Genitourinary System",
        "questionCount": 14
      },
      {
        "id": 169,
        "moduleId": "m43",
        "name": "Female Genital Tract",
        "section": "Genitourinary System",
        "questionCount": 5
      },
      {
        "id": 170,
        "moduleId": "m44",
        "name": "Male Genital Tract",
        "section": "Genitourinary System",
        "questionCount": 21
      },
      {
        "id": 171,
        "moduleId": "m45",
        "name": "Alcoholic and Infectious Liver Diseases",
        "section": "Gastrointestinal System",
        "questionCount": 20
      },
      {
        "id": 172,
        "moduleId": "m46",
        "name": "Autoimmune and Metabolic Liver Diseases",
        "section": "Gastrointestinal System",
        "questionCount": 7
      },
      {
        "id": 173,
        "moduleId": "m47",
        "name": "Neoplasms of Liver and Biliary Tract",
        "section": "Gastrointestinal System",
        "questionCount": 8
      },
      {
        "id": 174,
        "moduleId": "m48",
        "name": "Gall Bladder and Pancreas",
        "section": "Gastrointestinal System",
        "questionCount": 6
      },
      {
        "id": 175,
        "moduleId": "m49",
        "name": "Esophagus",
        "section": "Gastrointestinal System",
        "questionCount": 16
      },
      {
        "id": 176,
        "moduleId": "m50",
        "name": "Stomach",
        "section": "Gastrointestinal System",
        "questionCount": 10
      },
      {
        "id": 177,
        "moduleId": "m51",
        "name": "Small Intestine",
        "section": "Gastrointestinal System",
        "questionCount": 18
      },
      {
        "id": 178,
        "moduleId": "m52",
        "name": "Large Intestine - Non Neoplastic Conditions",
        "section": "Gastrointestinal System",
        "questionCount": 21
      },
      {
        "id": 179,
        "moduleId": "m53",
        "name": "Congenital Anomalies, ARDS, Infections",
        "section": "Respiratory System",
        "questionCount": 10
      },
      {
        "id": 180,
        "moduleId": "m54",
        "name": "Obstructive and Restrictive Lung Diseases",
        "section": "Respiratory System",
        "questionCount": 31
      },
      {
        "id": 181,
        "moduleId": "m55",
        "name": "Lung Tumors",
        "section": "Respiratory System",
        "questionCount": 1
      },
      {
        "id": 182,
        "moduleId": "m56",
        "name": "Pituitary, Parathyroid and Pancreas",
        "section": "Endocrine System and Breast",
        "questionCount": 11
      },
      {
        "id": 183,
        "moduleId": "m57",
        "name": "Thyroid Glands",
        "section": "Endocrine System and Breast",
        "questionCount": 11
      },
      {
        "id": 184,
        "moduleId": "m58",
        "name": "The Breast",
        "section": "Endocrine System and Breast",
        "questionCount": 16
      },
      {
        "id": 185,
        "moduleId": "m59",
        "name": "Developmental Disorders, Infections and Tumors of Bone",
        "section": "Bone and Musculoskeletal System",
        "questionCount": 21
      },
      {
        "id": 186,
        "moduleId": "m60",
        "name": "Joints and Soft Tissue Tumors",
        "section": "Bone and Musculoskeletal System",
        "questionCount": 5
      },
      {
        "id": 187,
        "moduleId": "m61",
        "name": "Skin Pathology",
        "section": "Skin Pathology",
        "questionCount": 88
      },
      {
        "id": 188,
        "moduleId": "m62",
        "name": "Infective and Vascular CNS Pathology",
        "section": "Nervous System",
        "questionCount": 7
      },
      {
        "id": 189,
        "moduleId": "m63",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Nervous System",
        "questionCount": 17
      }
    ]
  },
  {
    "subjectId": 1000185,
    "name": "Microbiology",
    "questionCount": 1631,
    "moduleCount": 31,
    "modules": [
      {
        "id": 190,
        "moduleId": "m0",
        "name": "General Microbiology",
        "section": "General Microbiology",
        "questionCount": 728
      },
      {
        "id": 191,
        "moduleId": "m1",
        "name": "Components of Immune System",
        "section": "Immunology",
        "questionCount": 26
      },
      {
        "id": 192,
        "moduleId": "m2",
        "name": "Structure and Functions of the Immune System & Immune Response",
        "section": "Immunology",
        "questionCount": 65
      },
      {
        "id": 193,
        "moduleId": "m3",
        "name": "Hypersensitivity",
        "section": "Immunology",
        "questionCount": 60
      },
      {
        "id": 194,
        "moduleId": "m4",
        "name": "Streptococci and Enterococci",
        "section": "Bacteriology",
        "questionCount": 11
      },
      {
        "id": 195,
        "moduleId": "m5",
        "name": "Corynebacterium, Listeria and Actinomyces",
        "section": "Bacteriology",
        "questionCount": 15
      },
      {
        "id": 196,
        "moduleId": "m6",
        "name": "Clostridium and Bacillus",
        "section": "Bacteriology",
        "questionCount": 23
      },
      {
        "id": 197,
        "moduleId": "m7",
        "name": "Mycobacteria Tuberculosis",
        "section": "Bacteriology",
        "questionCount": 31
      },
      {
        "id": 198,
        "moduleId": "m8",
        "name": "Other Mycobacteria",
        "section": "Bacteriology",
        "questionCount": 2
      },
      {
        "id": 199,
        "moduleId": "m9",
        "name": "Escherichia, Proteus and Klebsiella",
        "section": "Bacteriology",
        "questionCount": 8
      },
      {
        "id": 200,
        "moduleId": "m10",
        "name": "Shigella and Salmonella",
        "section": "Bacteriology",
        "questionCount": 12
      },
      {
        "id": 201,
        "moduleId": "m11",
        "name": "Vibrio and Campylobacterales",
        "section": "Bacteriology",
        "questionCount": 8
      },
      {
        "id": 202,
        "moduleId": "m12",
        "name": "Pseudomonas and Burkholderiales",
        "section": "Bacteriology",
        "questionCount": 2
      },
      {
        "id": 203,
        "moduleId": "m13",
        "name": "Haemophilus",
        "section": "Bacteriology",
        "questionCount": 34
      },
      {
        "id": 204,
        "moduleId": "m14",
        "name": "Miscellaneous Bacteria - Yersinia, Brucella, Bartonella, Legionella",
        "section": "Bacteriology",
        "questionCount": 31
      },
      {
        "id": 205,
        "moduleId": "m15",
        "name": "Gram Negative Cocci",
        "section": "Bacteriology",
        "questionCount": 41
      },
      {
        "id": 206,
        "moduleId": "m16",
        "name": "Rickettsia, Chlamydia and Mycoplasma",
        "section": "Bacteriology",
        "questionCount": 15
      },
      {
        "id": 207,
        "moduleId": "m17",
        "name": "Spirochetes",
        "section": "Bacteriology",
        "questionCount": 14
      },
      {
        "id": 208,
        "moduleId": "m18",
        "name": "General Properties of Viruses",
        "section": "Virology",
        "questionCount": 6
      },
      {
        "id": 209,
        "moduleId": "m19",
        "name": "Hepatitis",
        "section": "Virology",
        "questionCount": 106
      },
      {
        "id": 210,
        "moduleId": "m20",
        "name": "Arboviruses and Picorna Viruses",
        "section": "Virology",
        "questionCount": 10
      },
      {
        "id": 211,
        "moduleId": "m21",
        "name": "Miscellaneous Viruses - Rubella, Coronaviruses, Prions, Rotavirus, Filovirus, Zika Virus and Nipah Virus",
        "section": "Virology",
        "questionCount": 123
      },
      {
        "id": 212,
        "moduleId": "m22",
        "name": "Superficial and Systemic Mycoses",
        "section": "Mycology",
        "questionCount": 64
      },
      {
        "id": 213,
        "moduleId": "m23",
        "name": "Opportunistic Mycoses",
        "section": "Mycology",
        "questionCount": 23
      },
      {
        "id": 214,
        "moduleId": "m24",
        "name": "General Parasitology",
        "section": "Parasitology",
        "questionCount": 106
      },
      {
        "id": 215,
        "moduleId": "m25",
        "name": "Protozoology - Amoebae, Ciliates & Flagellates",
        "section": "Parasitology",
        "questionCount": 14
      },
      {
        "id": 216,
        "moduleId": "m26",
        "name": "Protozoology - Sporozoa",
        "section": "Parasitology",
        "questionCount": 16
      },
      {
        "id": 217,
        "moduleId": "m27",
        "name": "Helminthology - Cestodes & Trematodes",
        "section": "Parasitology",
        "questionCount": 8
      },
      {
        "id": 218,
        "moduleId": "m28",
        "name": "Helminthology - Nematodes",
        "section": "Parasitology",
        "questionCount": 22
      },
      {
        "id": 219,
        "moduleId": "m29",
        "name": "Applied Microbiology",
        "section": "Applied Microbiology",
        "questionCount": 7
      },
      {
        "id": 220,
        "moduleId": "m30",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Applied Microbiology",
        "questionCount": 0
      }
    ]
  },
  {
    "subjectId": 1000114,
    "name": "Pharmacology",
    "questionCount": 1295,
    "moduleCount": 52,
    "modules": [
      {
        "id": 221,
        "moduleId": "m0",
        "name": "Pharmacokinetics",
        "section": "General Pharmacology",
        "questionCount": 22
      },
      {
        "id": 222,
        "moduleId": "m1",
        "name": "Clinical Trials and Miscellaneous",
        "section": "General Pharmacology",
        "questionCount": 447
      },
      {
        "id": 223,
        "moduleId": "m2",
        "name": "Sympathomimetics",
        "section": "Autonomic Nervous System",
        "questionCount": 41
      },
      {
        "id": 224,
        "moduleId": "m3",
        "name": "Drugs for Glaucoma",
        "section": "Autonomic Nervous System",
        "questionCount": 8
      },
      {
        "id": 740,
        "moduleId": "m51",
        "name": "Parasympathomimetics & Cholinergic Agonists",
        "section": "Autonomic Nervous System",
        "questionCount": 31
      },
      {
        "id": 225,
        "moduleId": "m4",
        "name": "Anti-Anginal Drugs",
        "section": "Cardiovascular System",
        "questionCount": 10
      },
      {
        "id": 226,
        "moduleId": "m5",
        "name": "Heart Failure Drugs",
        "section": "Cardiovascular System",
        "questionCount": 34
      },
      {
        "id": 227,
        "moduleId": "m6",
        "name": "Antihypertensive Drugs",
        "section": "Cardiovascular System",
        "questionCount": 5
      },
      {
        "id": 228,
        "moduleId": "m7",
        "name": "Diuretics",
        "section": "Cardiovascular System",
        "questionCount": 46
      },
      {
        "id": 229,
        "moduleId": "m8",
        "name": "Anti-Arrhythmic Drugs",
        "section": "Cardiovascular System",
        "questionCount": 12
      },
      {
        "id": 230,
        "moduleId": "m9",
        "name": "Hypolipidemic Drugs",
        "section": "Cardiovascular System",
        "questionCount": 3
      },
      {
        "id": 231,
        "moduleId": "m10",
        "name": "Renin-Angiotensin-Aldosterone System",
        "section": "Cardiovascular System",
        "questionCount": 13
      },
      {
        "id": 232,
        "moduleId": "m11",
        "name": "Anti-diuretics",
        "section": "Cardiovascular System",
        "questionCount": 4
      },
      {
        "id": 233,
        "moduleId": "m12",
        "name": "Anti-epileptics I",
        "section": "Central and Peripheral Nervous System",
        "questionCount": 28
      },
      {
        "id": 234,
        "moduleId": "m13",
        "name": "Anti-manic Drugs",
        "section": "Central and Peripheral Nervous System",
        "questionCount": 14
      },
      {
        "id": 235,
        "moduleId": "m14",
        "name": "Antidepressant and Antianxiety Drugs",
        "section": "Central and Peripheral Nervous System",
        "questionCount": 33
      },
      {
        "id": 236,
        "moduleId": "m15",
        "name": "Opioids - Functions and Classification",
        "section": "Central and Peripheral Nervous System",
        "questionCount": 5
      },
      {
        "id": 237,
        "moduleId": "m16",
        "name": "Synthetic Opioids",
        "section": "Central and Peripheral Nervous System",
        "questionCount": 2
      },
      {
        "id": 238,
        "moduleId": "m17",
        "name": "Opioid Antagonists",
        "section": "Central and Peripheral Nervous System",
        "questionCount": 8
      },
      {
        "id": 239,
        "moduleId": "m18",
        "name": "General Principles of Antimicrobial Therapy",
        "section": "Antimicrobials",
        "questionCount": 24
      },
      {
        "id": 240,
        "moduleId": "m19",
        "name": "Antimalarial Drugs",
        "section": "Antimicrobials",
        "questionCount": 5
      },
      {
        "id": 241,
        "moduleId": "m20",
        "name": "Sulfonamides, Quinolones and Urinary Antiseptics",
        "section": "Antimicrobials",
        "questionCount": 17
      },
      {
        "id": 242,
        "moduleId": "m21",
        "name": "Antimicrobials Acting on 30S Subunit",
        "section": "Antimicrobials",
        "questionCount": 4
      },
      {
        "id": 243,
        "moduleId": "m22",
        "name": "Antiretroviral Drugs",
        "section": "Antimicrobials",
        "questionCount": 7
      },
      {
        "id": 244,
        "moduleId": "m23",
        "name": "Penicillins",
        "section": "Antimicrobials",
        "questionCount": 16
      },
      {
        "id": 245,
        "moduleId": "m24",
        "name": "Cephalosporins, Vancomycin and Carbapenems",
        "section": "Antimicrobials",
        "questionCount": 5
      },
      {
        "id": 246,
        "moduleId": "m25",
        "name": "Anti-Protozoal Agents and Anthelmintic Drugs",
        "section": "Antimicrobials",
        "questionCount": 7
      },
      {
        "id": 247,
        "moduleId": "m26",
        "name": "Antifungal Agents",
        "section": "Antimicrobials",
        "questionCount": 7
      },
      {
        "id": 248,
        "moduleId": "m27",
        "name": "First Line Drugs for Tuberculosis",
        "section": "Antimicrobials",
        "questionCount": 31
      },
      {
        "id": 249,
        "moduleId": "m28",
        "name": "Second Line Drugs for Tuberculosis",
        "section": "Antimicrobials",
        "questionCount": 3
      },
      {
        "id": 250,
        "moduleId": "m29",
        "name": "Anti-leprosy Drugs",
        "section": "Antimicrobials",
        "questionCount": 5
      },
      {
        "id": 251,
        "moduleId": "m30",
        "name": "Anti-virals (Non-retroviral)",
        "section": "Antimicrobials",
        "questionCount": 10
      },
      {
        "id": 252,
        "moduleId": "m31",
        "name": "Hypothalamus and Pituitary",
        "section": "Endocrine System",
        "questionCount": 5
      },
      {
        "id": 253,
        "moduleId": "m32",
        "name": "Thyroid and Antithyroid Agents",
        "section": "Endocrine System",
        "questionCount": 8
      },
      {
        "id": 254,
        "moduleId": "m33",
        "name": "Corticosteroids",
        "section": "Endocrine System",
        "questionCount": 31
      },
      {
        "id": 255,
        "moduleId": "m34",
        "name": "Osteoporosis and Calcium Metabolism",
        "section": "Endocrine System",
        "questionCount": 19
      },
      {
        "id": 256,
        "moduleId": "m35",
        "name": "Anti-Diabetic Drugs - Oral",
        "section": "Endocrine System",
        "questionCount": 69
      },
      {
        "id": 257,
        "moduleId": "m36",
        "name": "OCPs, Estrogens and Progestins",
        "section": "Endocrine System",
        "questionCount": 5
      },
      {
        "id": 258,
        "moduleId": "m37",
        "name": "Androgens and Drugs for Erectile Dysfunction",
        "section": "Endocrine System",
        "questionCount": 8
      },
      {
        "id": 259,
        "moduleId": "m38",
        "name": "Drugs Acting on Uterus",
        "section": "Endocrine System",
        "questionCount": 2
      },
      {
        "id": 260,
        "moduleId": "m39",
        "name": "NSAIDs",
        "section": "Autacoids",
        "questionCount": 28
      },
      {
        "id": 261,
        "moduleId": "m40",
        "name": "Anti-migraine and Antigout drugs",
        "section": "Autacoids",
        "questionCount": 8
      },
      {
        "id": 262,
        "moduleId": "m41",
        "name": "Anti-rheumatoid drugs",
        "section": "Autacoids",
        "questionCount": 1
      },
      {
        "id": 263,
        "moduleId": "m42",
        "name": "Antiplatelets, Fibrinolytics and Antifibrinolytics",
        "section": "Hematology",
        "questionCount": 11
      },
      {
        "id": 264,
        "moduleId": "m43",
        "name": "Anticoagulants",
        "section": "Hematology",
        "questionCount": 25
      },
      {
        "id": 265,
        "moduleId": "m44",
        "name": "Respiratory System",
        "section": "Respiratory System",
        "questionCount": 21
      },
      {
        "id": 266,
        "moduleId": "m45",
        "name": "Acid Peptic Disorders and Inflammatory Bowel Disease",
        "section": "Gastrointestinal System",
        "questionCount": 30
      },
      {
        "id": 267,
        "moduleId": "m46",
        "name": "Anti-emetics and Drugs Affecting Gastrointestinal Motility",
        "section": "Gastrointestinal System",
        "questionCount": 42
      },
      {
        "id": 268,
        "moduleId": "m47",
        "name": "Cell Cycle Specific Cytotoxic Drugs",
        "section": "Anti-Neoplastic Agents",
        "questionCount": 70
      },
      {
        "id": 269,
        "moduleId": "m48",
        "name": "Monoclonal Antibodies",
        "section": "Anti-Neoplastic Agents",
        "questionCount": 12
      },
      {
        "id": 270,
        "moduleId": "m49",
        "name": "Interleukins, Growth Factors and Targeted Therapies",
        "section": "Anti-Neoplastic Agents",
        "questionCount": 8
      },
      {
        "id": 271,
        "moduleId": "m50",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Anti-Neoplastic Agents",
        "questionCount": 1
      },
    ]
  },
  {
    "subjectId": 1000115,
    "name": "Forensic Medicine",
    "questionCount": 1054,
    "moduleCount": 21,
    "modules": [
      {
        "id": 272,
        "moduleId": "m0",
        "name": "Skeletal and Dental Age Determination",
        "section": "Identification",
        "questionCount": 45
      },
      {
        "id": 273,
        "moduleId": "m1",
        "name": "Race, Sex and Stature Determination",
        "section": "Identification",
        "questionCount": 12
      },
      {
        "id": 274,
        "moduleId": "m2",
        "name": "Fingerprint and Tattoos",
        "section": "Identification",
        "questionCount": 21
      },
      {
        "id": 275,
        "moduleId": "m3",
        "name": "BNS, BNSS, and BSA",
        "section": "Medical Jurisprudence",
        "questionCount": 118
      },
      {
        "id": 276,
        "moduleId": "m4",
        "name": "Death and Post-Mortem Changes",
        "section": "Death, PM Changes",
        "questionCount": 121
      },
      {
        "id": 277,
        "moduleId": "m5",
        "name": "Medico Legal Autopsy",
        "section": "Medico Legal Autopsy",
        "questionCount": 94
      },
      {
        "id": 278,
        "moduleId": "m6",
        "name": "Mechanical Injuries",
        "section": "Injuries",
        "questionCount": 38
      },
      {
        "id": 279,
        "moduleId": "m7",
        "name": "Regional Injuries",
        "section": "Injuries",
        "questionCount": 12
      },
      {
        "id": 280,
        "moduleId": "m8",
        "name": "Thermal Injuries",
        "section": "Injuries",
        "questionCount": 9
      },
      {
        "id": 281,
        "moduleId": "m9",
        "name": "Firearm Injuries and Blast Injuries",
        "section": "Injuries",
        "questionCount": 69
      },
      {
        "id": 282,
        "moduleId": "m10",
        "name": "Mechanical Asphyxia",
        "section": "Asphyxia",
        "questionCount": 49
      },
      {
        "id": 283,
        "moduleId": "m11",
        "name": "Drowning",
        "section": "Asphyxia",
        "questionCount": 37
      },
      {
        "id": 284,
        "moduleId": "m12",
        "name": "Sexual Offences and Abortion",
        "section": "Sexual Offences and Abortion",
        "questionCount": 66
      },
      {
        "id": 285,
        "moduleId": "m13",
        "name": "Childhood Violence, Infanticide and Starvation",
        "section": "Childhood Violence, Infanticide and Starvation",
        "questionCount": 17
      },
      {
        "id": 286,
        "moduleId": "m14",
        "name": "Poisoning: General Considerations",
        "section": "Toxicology",
        "questionCount": 217
      },
      {
        "id": 287,
        "moduleId": "m15",
        "name": "Organophosphorus Poisoning",
        "section": "Toxicology",
        "questionCount": 39
      },
      {
        "id": 288,
        "moduleId": "m16",
        "name": "Corrosives and Asphyxiants",
        "section": "Toxicology",
        "questionCount": 4
      },
      {
        "id": 289,
        "moduleId": "m17",
        "name": "Alcohol Poisoning",
        "section": "Toxicology",
        "questionCount": 37
      },
      {
        "id": 290,
        "moduleId": "m18",
        "name": "Inorganic Irritants - Metallic and Non-metallic",
        "section": "Toxicology",
        "questionCount": 8
      },
      {
        "id": 291,
        "moduleId": "m19",
        "name": "Organic Irritants - Plant and Animal Poisons",
        "section": "Toxicology",
        "questionCount": 39
      },
      {
        "id": 292,
        "moduleId": "m20",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Toxicology",
        "questionCount": 2
      }
    ]
  },
  {
    "subjectId": 1000116,
    "name": "ENT",
    "questionCount": 1200,
    "moduleCount": 36,
    "modules": [
      {
        "id": 293,
        "moduleId": "m0",
        "name": "Embryology of Ear and Malformations",
        "section": "Ear",
        "questionCount": 20
      },
      {
        "id": 294,
        "moduleId": "m1",
        "name": "Anatomy of External Ear",
        "section": "Ear",
        "questionCount": 49
      },
      {
        "id": 295,
        "moduleId": "m2",
        "name": "Anatomy of Middle Ear",
        "section": "Ear",
        "questionCount": 170
      },
      {
        "id": 296,
        "moduleId": "m3",
        "name": "Anatomy of Mastoid",
        "section": "Ear",
        "questionCount": 14
      },
      {
        "id": 297,
        "moduleId": "m4",
        "name": "Anatomy of Inner Ear",
        "section": "Ear",
        "questionCount": 12
      },
      {
        "id": 298,
        "moduleId": "m5",
        "name": "Disorders of External Ear",
        "section": "Ear",
        "questionCount": 4
      },
      {
        "id": 299,
        "moduleId": "m6",
        "name": "Cholesteatoma and Types of CSOM",
        "section": "Ear",
        "questionCount": 13
      },
      {
        "id": 300,
        "moduleId": "m7",
        "name": "CSOM - Treatment and Complications",
        "section": "Ear",
        "questionCount": 29
      },
      {
        "id": 301,
        "moduleId": "m8",
        "name": "Otosclerosis",
        "section": "Ear",
        "questionCount": 36
      },
      {
        "id": 302,
        "moduleId": "m9",
        "name": "Meniere's Disease",
        "section": "Ear",
        "questionCount": 46
      },
      {
        "id": 303,
        "moduleId": "m10",
        "name": "Tumors of Ear",
        "section": "Ear",
        "questionCount": 3
      },
      {
        "id": 304,
        "moduleId": "m11",
        "name": "Anatomy of Facial Nerve",
        "section": "Ear",
        "questionCount": 18
      },
      {
        "id": 305,
        "moduleId": "m12",
        "name": "Facial Nerve Disorders",
        "section": "Ear",
        "questionCount": 6
      },
      {
        "id": 306,
        "moduleId": "m13",
        "name": "Eustachian Tube",
        "section": "Ear",
        "questionCount": 44
      },
      {
        "id": 307,
        "moduleId": "m14",
        "name": "Physiology of Hearing and Tuning Fork Tests",
        "section": "Ear",
        "questionCount": 38
      },
      {
        "id": 308,
        "moduleId": "m15",
        "name": "Audiometric Tests and Special Tests of Hearing",
        "section": "Ear",
        "questionCount": 29
      },
      {
        "id": 309,
        "moduleId": "m16",
        "name": "Anatomy of Nose",
        "section": "Nose",
        "questionCount": 2
      },
      {
        "id": 310,
        "moduleId": "m17",
        "name": "Anatomy of Paranasal Sinuses",
        "section": "Nose",
        "questionCount": 20
      },
      {
        "id": 311,
        "moduleId": "m18",
        "name": "Physiology of Nose and Paranasal Sinuses",
        "section": "Nose",
        "questionCount": 14
      },
      {
        "id": 312,
        "moduleId": "m19",
        "name": "Epistaxis",
        "section": "Nose",
        "questionCount": 42
      },
      {
        "id": 313,
        "moduleId": "m20",
        "name": "Congenital Anomalies of Nose and Disease of Nose",
        "section": "Nose",
        "questionCount": 277
      },
      {
        "id": 314,
        "moduleId": "m21",
        "name": "Rhinitis",
        "section": "Nose",
        "questionCount": 29
      },
      {
        "id": 315,
        "moduleId": "m22",
        "name": "Disorder of Nasal Septum and Nasal Polyposis",
        "section": "Nose",
        "questionCount": 25
      },
      {
        "id": 316,
        "moduleId": "m23",
        "name": "Trauma of Nose and Face",
        "section": "Nose",
        "questionCount": 6
      },
      {
        "id": 317,
        "moduleId": "m24",
        "name": "Tumors of Nose and PNS",
        "section": "Nose",
        "questionCount": 3
      },
      {
        "id": 318,
        "moduleId": "m25",
        "name": "Sinusitis and its Complication",
        "section": "Nose",
        "questionCount": 4
      },
      {
        "id": 319,
        "moduleId": "m26",
        "name": "Anatomy and Physiology of Pharynx",
        "section": "Pharynx",
        "questionCount": 22
      },
      {
        "id": 320,
        "moduleId": "m27",
        "name": "Adenoids",
        "section": "Pharynx",
        "questionCount": 6
      },
      {
        "id": 321,
        "moduleId": "m28",
        "name": "Tonsils",
        "section": "Pharynx",
        "questionCount": 39
      },
      {
        "id": 322,
        "moduleId": "m29",
        "name": "Nasopharyngeal Angiofibroma",
        "section": "Pharynx",
        "questionCount": 16
      },
      {
        "id": 323,
        "moduleId": "m30",
        "name": "Nasopharyngeal Carcinoma",
        "section": "Pharynx",
        "questionCount": 29
      },
      {
        "id": 324,
        "moduleId": "m31",
        "name": "Anatomy and Physiology of Larynx",
        "section": "Larynx",
        "questionCount": 25
      },
      {
        "id": 325,
        "moduleId": "m32",
        "name": "Stridor and Congenital Conditions of Larynx",
        "section": "Larynx",
        "questionCount": 25
      },
      {
        "id": 326,
        "moduleId": "m33",
        "name": "Voice and Speech Disorders",
        "section": "Larynx",
        "questionCount": 7
      },
      {
        "id": 327,
        "moduleId": "m34",
        "name": "Laryngeal Carcinoma",
        "section": "Larynx",
        "questionCount": 30
      },
      {
        "id": 328,
        "moduleId": "m35",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Instruments",
        "questionCount": 48
      }
    ]
  },
  {
    "subjectId": 1000117,
    "name": "Ophthalmology",
    "questionCount": 1556,
    "moduleCount": 26,
    "modules": [
      {
        "id": 329,
        "moduleId": "m0",
        "name": "Anatomy and Development of Eye",
        "section": "Basics of Ophthalmology",
        "questionCount": 29
      },
      {
        "id": 330,
        "moduleId": "m1",
        "name": "Elementary Optics and Physiology of Vision",
        "section": "Basics of Ophthalmology",
        "questionCount": 33
      },
      {
        "id": 331,
        "moduleId": "m2",
        "name": "Myopia and Hypermetropia",
        "section": "Errors in Optics",
        "questionCount": 18
      },
      {
        "id": 332,
        "moduleId": "m3",
        "name": "Astigmatism and Errors of Accomodation",
        "section": "Errors in Optics",
        "questionCount": 16
      },
      {
        "id": 333,
        "moduleId": "m4",
        "name": "Conjunctiva",
        "section": "Conjunctiva",
        "questionCount": 195
      },
      {
        "id": 334,
        "moduleId": "m5",
        "name": "Sclera",
        "section": "Sclera",
        "questionCount": 76
      },
      {
        "id": 335,
        "moduleId": "m6",
        "name": "Basics of Cornea and Infectious Keratitis",
        "section": "Cornea",
        "questionCount": 101
      },
      {
        "id": 336,
        "moduleId": "m7",
        "name": "Non-infectious Disorders of Cornea",
        "section": "Cornea",
        "questionCount": 20
      },
      {
        "id": 337,
        "moduleId": "m8",
        "name": "Retinal Vascular Disorders and Retinal Detachment",
        "section": "Retina and Vitreous",
        "questionCount": 194
      },
      {
        "id": 338,
        "moduleId": "m9",
        "name": "Macular Disorders, Retinal Dystrophies, and Vitreal Disorders",
        "section": "Retina and Vitreous",
        "questionCount": 30
      },
      {
        "id": 339,
        "moduleId": "m10",
        "name": "Lens - Introduction, Types of Cataract and Clinical Features",
        "section": "Lens",
        "questionCount": 88
      },
      {
        "id": 340,
        "moduleId": "m11",
        "name": "Lens - Cataract Surgery, Complications and IOLs",
        "section": "Lens",
        "questionCount": 43
      },
      {
        "id": 341,
        "moduleId": "m12",
        "name": "Glaucoma",
        "section": "Glaucoma",
        "questionCount": 222
      },
      {
        "id": 342,
        "moduleId": "m13",
        "name": "Uveitis - Anterior and Intermediate",
        "section": "Uveal Tract",
        "questionCount": 36
      },
      {
        "id": 343,
        "moduleId": "m14",
        "name": "Uveitis - Posterior and Panuveitis",
        "section": "Uveal Tract",
        "questionCount": 11
      },
      {
        "id": 344,
        "moduleId": "m15",
        "name": "Disorders of the Eyelid",
        "section": "Lid and Lacrimal Apparatus",
        "questionCount": 30
      },
      {
        "id": 345,
        "moduleId": "m16",
        "name": "Disorders of Lacrimal Apparatus and Glands of the Eye",
        "section": "Lid and Lacrimal Apparatus",
        "questionCount": 33
      },
      {
        "id": 346,
        "moduleId": "m17",
        "name": "Orbit Anatomy and Ocular Injuries",
        "section": "Orbit",
        "questionCount": 49
      },
      {
        "id": 347,
        "moduleId": "m18",
        "name": "Diseases of the Orbit",
        "section": "Orbit",
        "questionCount": 11
      },
      {
        "id": 348,
        "moduleId": "m19",
        "name": "Strabismus - Introduction, Symptomatology, and Evaluation",
        "section": "Specific Disorders of the Eye",
        "questionCount": 15
      },
      {
        "id": 349,
        "moduleId": "m20",
        "name": "Strabismus - Types and Treatment",
        "section": "Specific Disorders of the Eye",
        "questionCount": 56
      },
      {
        "id": 350,
        "moduleId": "m21",
        "name": "Disorders of Visual Pathway and Pupillary Reflexes",
        "section": "Specific Disorders of the Eye",
        "questionCount": 73
      },
      {
        "id": 351,
        "moduleId": "m22",
        "name": "Disorders of Optic Nerve and Gaze Palsies",
        "section": "Specific Disorders of the Eye",
        "questionCount": 86
      },
      {
        "id": 352,
        "moduleId": "m23",
        "name": "Tumors of Eye",
        "section": "Specific Disorders of the Eye",
        "questionCount": 44
      },
      {
        "id": 353,
        "moduleId": "m24",
        "name": "Practical Ophthalmology",
        "section": "Practical Ophthalmology",
        "questionCount": 11
      },
      {
        "id": 354,
        "moduleId": "m25",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Instruments",
        "questionCount": 36
      }
    ]
  },
  {
    "subjectId": 1000118,
    "name": "PSM",
    "questionCount": 2184,
    "moduleCount": 56,
    "modules": [
      {
        "id": 355,
        "moduleId": "m0",
        "name": "History of Medicine",
        "section": "History of Medicine",
        "questionCount": 701
      },
      {
        "id": 356,
        "moduleId": "m1",
        "name": "Health Determinants and Indicators",
        "section": "Concepts of Health and Disease",
        "questionCount": 25
      },
      {
        "id": 357,
        "moduleId": "m2",
        "name": "Concepts of Disease and Prevention",
        "section": "Concepts of Health and Disease",
        "questionCount": 208
      },
      {
        "id": 358,
        "moduleId": "m3",
        "name": "Principles of Epidemiology",
        "section": "Epidemiology",
        "questionCount": 116
      },
      {
        "id": 359,
        "moduleId": "m4",
        "name": "Analytical Epidemiology",
        "section": "Epidemiology",
        "questionCount": 3
      },
      {
        "id": 360,
        "moduleId": "m5",
        "name": "Experimental Epidemiology",
        "section": "Epidemiology",
        "questionCount": 3
      },
      {
        "id": 361,
        "moduleId": "m6",
        "name": "Basic Definitions in Infectious Disease Epidemiology",
        "section": "Epidemiology",
        "questionCount": 15
      },
      {
        "id": 362,
        "moduleId": "m7",
        "name": "Dynamics of Disease Transmission",
        "section": "Epidemiology",
        "questionCount": 26
      },
      {
        "id": 363,
        "moduleId": "m8",
        "name": "Principles of Immunization and Vaccination",
        "section": "Epidemiology",
        "questionCount": 13
      },
      {
        "id": 364,
        "moduleId": "m9",
        "name": "Vaccine Production and Storage",
        "section": "Epidemiology",
        "questionCount": 31
      },
      {
        "id": 365,
        "moduleId": "m10",
        "name": "Sterilization and Disinfection",
        "section": "Epidemiology",
        "questionCount": 3
      },
      {
        "id": 366,
        "moduleId": "m11",
        "name": "Screening",
        "section": "Screening",
        "questionCount": 121
      },
      {
        "id": 367,
        "moduleId": "m12",
        "name": "Viral Respiratory Infections",
        "section": "Epidemiology of Communicable Diseases",
        "questionCount": 13
      },
      {
        "id": 368,
        "moduleId": "m13",
        "name": "Bacterial Respiratory Infections",
        "section": "Epidemiology of Communicable Diseases",
        "questionCount": 8
      },
      {
        "id": 369,
        "moduleId": "m14",
        "name": "Intestinal Infections",
        "section": "Epidemiology of Communicable Diseases",
        "questionCount": 4
      },
      {
        "id": 370,
        "moduleId": "m15",
        "name": "Arthropod-Borne Infections",
        "section": "Epidemiology of Communicable Diseases",
        "questionCount": 2
      },
      {
        "id": 371,
        "moduleId": "m16",
        "name": "Zoonotic Infections - Viral",
        "section": "Epidemiology of Communicable Diseases",
        "questionCount": 1
      },
      {
        "id": 372,
        "moduleId": "m17",
        "name": "Zoonotic Infections - Bacterial & Parasitic",
        "section": "Epidemiology of Communicable Diseases",
        "questionCount": 1
      },
      {
        "id": 373,
        "moduleId": "m18",
        "name": "STDs and Surface Infections",
        "section": "Epidemiology of Communicable Diseases",
        "questionCount": 3
      },
      {
        "id": 374,
        "moduleId": "m19",
        "name": "Non-Communicable Diseases - Cardiovascular Diseases and Diabetes",
        "section": "Epidemiology of Non-Communicable Diseases",
        "questionCount": 119
      },
      {
        "id": 375,
        "moduleId": "m20",
        "name": "Non-Communicable Diseases - Cancer, Obesity and Blindness",
        "section": "Epidemiology of Non-Communicable Diseases",
        "questionCount": 11
      },
      {
        "id": 376,
        "moduleId": "m21",
        "name": "National Health Programmes I - NVBDCP",
        "section": "Indian Health Programmes",
        "questionCount": 14
      },
      {
        "id": 377,
        "moduleId": "m22",
        "name": "National Health Programmes II - NLEP, NTEP & NACO",
        "section": "Indian Health Programmes",
        "questionCount": 5
      },
      {
        "id": 378,
        "moduleId": "m23",
        "name": "National Health Programmes III - NIS, JSY, RBSK and Others",
        "section": "Indian Health Programmes",
        "questionCount": 34
      },
      {
        "id": 379,
        "moduleId": "m24",
        "name": "Demography I: Demographic Cycle, Annual Growth Rate and Age Pyramid",
        "section": "Demography and Family Planning",
        "questionCount": 56
      },
      {
        "id": 380,
        "moduleId": "m25",
        "name": "Demography II: Demographic Indicators",
        "section": "Demography and Family Planning",
        "questionCount": 12
      },
      {
        "id": 381,
        "moduleId": "m26",
        "name": "Family Planning",
        "section": "Demography and Family Planning",
        "questionCount": 52
      },
      {
        "id": 382,
        "moduleId": "m27",
        "name": "Preventive Obstetrics, Paediatrics and Geriatrics",
        "section": "Preventive Obstetrics, Paediatrics and Geriatrics",
        "questionCount": 7
      },
      {
        "id": 383,
        "moduleId": "m28",
        "name": "Micronutrients and Water",
        "section": "Nutrition and Health",
        "questionCount": 4
      },
      {
        "id": 384,
        "moduleId": "m29",
        "name": "Food Quality and Processing",
        "section": "Nutrition and Health",
        "questionCount": 21
      },
      {
        "id": 385,
        "moduleId": "m30",
        "name": "Concepts of Sociology and Psychology",
        "section": "Medicine and Social Sciences",
        "questionCount": 10
      },
      {
        "id": 386,
        "moduleId": "m31",
        "name": "Social Organization and Economics",
        "section": "Medicine and Social Sciences",
        "questionCount": 54
      },
      {
        "id": 387,
        "moduleId": "m32",
        "name": "Water - I: Sources and purification of water",
        "section": "Environment and Health",
        "questionCount": 28
      },
      {
        "id": 388,
        "moduleId": "m33",
        "name": "Water- II: Disinfection of water",
        "section": "Environment and Health",
        "questionCount": 8
      },
      {
        "id": 389,
        "moduleId": "m34",
        "name": "Water- III: Water Quality and Standards",
        "section": "Environment and Health",
        "questionCount": 21
      },
      {
        "id": 390,
        "moduleId": "m35",
        "name": "Housing and Ventilation",
        "section": "Environment and Health",
        "questionCount": 1
      },
      {
        "id": 391,
        "moduleId": "m36",
        "name": "Light, Sound and Radiation",
        "section": "Environment and Health",
        "questionCount": 3
      },
      {
        "id": 392,
        "moduleId": "m37",
        "name": "Waste and Sewage Disposal",
        "section": "Environment and Health",
        "questionCount": 12
      },
      {
        "id": 393,
        "moduleId": "m38",
        "name": "Medical Entomology - Mosquitoes and Flies",
        "section": "Environment and Health",
        "questionCount": 23
      },
      {
        "id": 394,
        "moduleId": "m39",
        "name": "Medical Entomology - Ticks, Fleas and Mites",
        "section": "Environment and Health",
        "questionCount": 2
      },
      {
        "id": 395,
        "moduleId": "m40",
        "name": "Methods of Pest Control",
        "section": "Environment and Health",
        "questionCount": 22
      },
      {
        "id": 396,
        "moduleId": "m41",
        "name": "Biomedical Waste Management",
        "section": "Biomedical Waste Management",
        "questionCount": 54
      },
      {
        "id": 397,
        "moduleId": "m42",
        "name": "Disaster Management",
        "section": "Disaster Management",
        "questionCount": 13
      },
      {
        "id": 398,
        "moduleId": "m43",
        "name": "Occupational Health Diseases",
        "section": "Occupational Community Medicine",
        "questionCount": 27
      },
      {
        "id": 399,
        "moduleId": "m44",
        "name": "Communication for Health Education",
        "section": "Communication for Health Education",
        "questionCount": 86
      },
      {
        "id": 400,
        "moduleId": "m45",
        "name": "Health Planning and Management",
        "section": "Healthcare of the Community",
        "questionCount": 15
      },
      {
        "id": 401,
        "moduleId": "m46",
        "name": "Healthcare in India",
        "section": "Healthcare of the Community",
        "questionCount": 32
      },
      {
        "id": 402,
        "moduleId": "m47",
        "name": "International Health",
        "section": "International Health",
        "questionCount": 19
      },
      {
        "id": 403,
        "moduleId": "m48",
        "name": "Descriptive Statistics I - Probability and Data",
        "section": "Biostatistics",
        "questionCount": 14
      },
      {
        "id": 404,
        "moduleId": "m49",
        "name": "Descriptive Statistics II - Measures of Location",
        "section": "Biostatistics",
        "questionCount": 27
      },
      {
        "id": 405,
        "moduleId": "m50",
        "name": "Descriptive Statistics III - Measures of Dispersion",
        "section": "Biostatistics",
        "questionCount": 17
      },
      {
        "id": 406,
        "moduleId": "m51",
        "name": "Correlational and Predictive Techniques",
        "section": "Biostatistics",
        "questionCount": 1
      },
      {
        "id": 407,
        "moduleId": "m52",
        "name": "Tests of Significance",
        "section": "Biostatistics",
        "questionCount": 6
      },
      {
        "id": 408,
        "moduleId": "m53",
        "name": "Facets of Clinical Research and Biostatistics",
        "section": "Biostatistics",
        "questionCount": 17
      },
      {
        "id": 409,
        "moduleId": "m54",
        "name": "Mental Health",
        "section": "Mental Health and Genetics",
        "questionCount": 17
      },
      {
        "id": 410,
        "moduleId": "m55",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Mental Health and Genetics",
        "questionCount": 23
      }
    ]
  },
  {
    "subjectId": 1000119,
    "name": "Medicine",
    "questionCount": 2673,
    "moduleCount": 69,
    "modules": [
      {
        "id": 411,
        "moduleId": "m0",
        "name": "Clinical Hypotheses",
        "section": "General Medicine",
        "questionCount": 81
      },
      {
        "id": 412,
        "moduleId": "m1",
        "name": "Acid-Base Disorders",
        "section": "Acid-Base Disorders",
        "questionCount": 90
      },
      {
        "id": 413,
        "moduleId": "m2",
        "name": "General Principles of Endocrinology",
        "section": "Endocrine System",
        "questionCount": 63
      },
      {
        "id": 414,
        "moduleId": "m3",
        "name": "Disorders of Anterior Pituitary",
        "section": "Endocrine System",
        "questionCount": 23
      },
      {
        "id": 415,
        "moduleId": "m4",
        "name": "Pituitary Tumors and Sheehan Syndrome",
        "section": "Endocrine System",
        "questionCount": 9
      },
      {
        "id": 416,
        "moduleId": "m5",
        "name": "Posterior Pituitary - ADH, Diabetes Insipidus",
        "section": "Endocrine System",
        "questionCount": 30
      },
      {
        "id": 417,
        "moduleId": "m6",
        "name": "Thyroid Disorders - Management",
        "section": "Endocrine System",
        "questionCount": 47
      },
      {
        "id": 418,
        "moduleId": "m7",
        "name": "Thyroid Disorders - Clinical Features",
        "section": "Endocrine System",
        "questionCount": 32
      },
      {
        "id": 419,
        "moduleId": "m8",
        "name": "Types of Assessment for Diagnosis",
        "section": "Endocrine System",
        "questionCount": 7
      },
      {
        "id": 420,
        "moduleId": "m9",
        "name": "Cushing Syndrome",
        "section": "Endocrine System",
        "questionCount": 16
      },
      {
        "id": 421,
        "moduleId": "m10",
        "name": "Diabetes Mellitus - Clinical Features",
        "section": "Endocrine System",
        "questionCount": 44
      },
      {
        "id": 422,
        "moduleId": "m11",
        "name": "Diabetes Mellitus - Complications and Management",
        "section": "Endocrine System",
        "questionCount": 23
      },
      {
        "id": 423,
        "moduleId": "m12",
        "name": "Reproductive Endocrinology",
        "section": "Endocrine System",
        "questionCount": 0
      },
      {
        "id": 424,
        "moduleId": "m13",
        "name": "Disorders of Parathyroid and Calcium",
        "section": "Endocrine System",
        "questionCount": 38
      },
      {
        "id": 425,
        "moduleId": "m14",
        "name": "Hyperbilirubinemia and Functions of Liver",
        "section": "Hepatobiliary System",
        "questionCount": 2
      },
      {
        "id": 426,
        "moduleId": "m15",
        "name": "Alcoholic Liver Diseases and Non-Alcoholic Fatty Liver Disease",
        "section": "Hepatobiliary System",
        "questionCount": 78
      },
      {
        "id": 427,
        "moduleId": "m16",
        "name": "Autoimmune Liver Diseases",
        "section": "Hepatobiliary System",
        "questionCount": 6
      },
      {
        "id": 428,
        "moduleId": "m17",
        "name": "Acute Liver Failure and Complications of Cirrhosis",
        "section": "Hepatobiliary System",
        "questionCount": 38
      },
      {
        "id": 429,
        "moduleId": "m18",
        "name": "Hemochromatosis and Wilsons Disease",
        "section": "Hepatobiliary System",
        "questionCount": 5
      },
      {
        "id": 430,
        "moduleId": "m19",
        "name": "Portal Hypertension",
        "section": "Hepatobiliary System",
        "questionCount": 27
      },
      {
        "id": 431,
        "moduleId": "m20",
        "name": "Evaluation of Jaundice",
        "section": "Hepatobiliary System",
        "questionCount": 6
      },
      {
        "id": 432,
        "moduleId": "m21",
        "name": "Irritable Bowel Syndrome",
        "section": "Irritable Bowel Syndrome",
        "questionCount": 134
      },
      {
        "id": 433,
        "moduleId": "m22",
        "name": "Inflammatory Bowel Disease - Clinical Features and Diagnosis",
        "section": "Inflammatory Bowel Disease",
        "questionCount": 432
      },
      {
        "id": 434,
        "moduleId": "m23",
        "name": "Inflammatory Bowel Disease - Complications and Treatment",
        "section": "Inflammatory Bowel Disease",
        "questionCount": 138
      },
      {
        "id": 435,
        "moduleId": "m24",
        "name": "Malabsorption Syndrome",
        "section": "Inflammatory Bowel Disease",
        "questionCount": 6
      },
      {
        "id": 436,
        "moduleId": "m25",
        "name": "Large and medium vessel vasculitis",
        "section": "Rheumatological and Vascular Disorders",
        "questionCount": 9
      },
      {
        "id": 437,
        "moduleId": "m26",
        "name": "Small vessel vasculitis",
        "section": "Rheumatological and Vascular Disorders",
        "questionCount": 15
      },
      {
        "id": 438,
        "moduleId": "m27",
        "name": "Sjogrens Syndrome and Scleroderma",
        "section": "Rheumatological and Vascular Disorders",
        "questionCount": 3
      },
      {
        "id": 439,
        "moduleId": "m28",
        "name": "Dermatomyositis and Related Disorders",
        "section": "Rheumatological and Vascular Disorders",
        "questionCount": 1
      },
      {
        "id": 440,
        "moduleId": "m29",
        "name": "Antiphospholipid Antibody Syndrome",
        "section": "Rheumatological and Vascular Disorders",
        "questionCount": 6
      },
      {
        "id": 441,
        "moduleId": "m30",
        "name": "Rheumatoid Arthritis",
        "section": "Rheumatological and Vascular Disorders",
        "questionCount": 69
      },
      {
        "id": 442,
        "moduleId": "m31",
        "name": "Asthma & COPD",
        "section": "Respiratory System",
        "questionCount": 9
      },
      {
        "id": 443,
        "moduleId": "m32",
        "name": "Pneumonia",
        "section": "Respiratory System",
        "questionCount": 83
      },
      {
        "id": 444,
        "moduleId": "m33",
        "name": "Interstitial Lung Diseases and Sarcoidosis",
        "section": "Respiratory System",
        "questionCount": 12
      },
      {
        "id": 445,
        "moduleId": "m34",
        "name": "Bronchiectasis and Lung Abscess",
        "section": "Respiratory System",
        "questionCount": 14
      },
      {
        "id": 446,
        "moduleId": "m35",
        "name": "Pulmonary Function Tests",
        "section": "Respiratory System",
        "questionCount": 36
      },
      {
        "id": 447,
        "moduleId": "m36",
        "name": "Respiratory Failure and ARDS",
        "section": "Respiratory System",
        "questionCount": 48
      },
      {
        "id": 448,
        "moduleId": "m37",
        "name": "Neoplasms of the Lung",
        "section": "Respiratory System",
        "questionCount": 7
      },
      {
        "id": 449,
        "moduleId": "m38",
        "name": "Sleep Apnea",
        "section": "Respiratory System",
        "questionCount": 7
      },
      {
        "id": 450,
        "moduleId": "m39",
        "name": "Acute Kidney Injury",
        "section": "Renal System",
        "questionCount": 22
      },
      {
        "id": 451,
        "moduleId": "m40",
        "name": "Chronic Kidney Disease",
        "section": "Renal System",
        "questionCount": 27
      },
      {
        "id": 452,
        "moduleId": "m41",
        "name": "Renal Replacement Therapy",
        "section": "Renal System",
        "questionCount": 63
      },
      {
        "id": 453,
        "moduleId": "m42",
        "name": "Cysts and Inherited Disorders of the Kidney",
        "section": "Renal System",
        "questionCount": 4
      },
      {
        "id": 454,
        "moduleId": "m43",
        "name": "Renal Tubular Diseases of Kidney",
        "section": "Renal System",
        "questionCount": 41
      },
      {
        "id": 455,
        "moduleId": "m44",
        "name": "Diagnosis of cardiovascular disorders",
        "section": "Cardiovascular System",
        "questionCount": 8
      },
      {
        "id": 456,
        "moduleId": "m45",
        "name": "Supraventricular Arrhythmias",
        "section": "Cardiovascular System",
        "questionCount": 2
      },
      {
        "id": 457,
        "moduleId": "m46",
        "name": "Ventricular Arrhythmias and Heart Blocks",
        "section": "Cardiovascular System",
        "questionCount": 34
      },
      {
        "id": 458,
        "moduleId": "m47",
        "name": "Vascular Heart Diseases",
        "section": "Cardiovascular System",
        "questionCount": 17
      },
      {
        "id": 459,
        "moduleId": "m48",
        "name": "Ischemic Heart Disease - Presentation and Diagnosis",
        "section": "Cardiovascular System",
        "questionCount": 27
      },
      {
        "id": 460,
        "moduleId": "m49",
        "name": "Ischemic Heart Disease - Complications and Management",
        "section": "Cardiovascular System",
        "questionCount": 27
      },
      {
        "id": 461,
        "moduleId": "m50",
        "name": "Cardiomyopathy and Myocarditis",
        "section": "Cardiovascular System",
        "questionCount": 8
      },
      {
        "id": 462,
        "moduleId": "m51",
        "name": "Heart Failure",
        "section": "Cardiovascular System",
        "questionCount": 86
      },
      {
        "id": 463,
        "moduleId": "m52",
        "name": "DVT and Pulmonary Embolism",
        "section": "Cardiovascular System",
        "questionCount": 6
      },
      {
        "id": 464,
        "moduleId": "m53",
        "name": "Cerebral Neurology: Dementia, Death and Coma",
        "section": "Nervous System",
        "questionCount": 12
      },
      {
        "id": 465,
        "moduleId": "m54",
        "name": "Seizure and Epilepsy",
        "section": "Nervous System",
        "questionCount": 5
      },
      {
        "id": 466,
        "moduleId": "m55",
        "name": "Extrapyramidal Syndromes and Movement Disorders",
        "section": "Nervous System",
        "questionCount": 11
      },
      {
        "id": 467,
        "moduleId": "m56",
        "name": "Myasthenia Gravis and Other Neuromuscular Disorders",
        "section": "Nervous System",
        "questionCount": 13
      },
      {
        "id": 468,
        "moduleId": "m57",
        "name": "Guillain Barre Syndrome and Other Peripheral Neuropathies",
        "section": "Nervous System",
        "questionCount": 17
      },
      {
        "id": 469,
        "moduleId": "m58",
        "name": "Multiple Sclerosis and Other Demyelinating Disorders",
        "section": "Nervous System",
        "questionCount": 24
      },
      {
        "id": 470,
        "moduleId": "m59",
        "name": "Headache",
        "section": "Nervous System",
        "questionCount": 91
      },
      {
        "id": 471,
        "moduleId": "m60",
        "name": "Spinal Cord Disorders",
        "section": "Nervous System",
        "questionCount": 6
      },
      {
        "id": 472,
        "moduleId": "m61",
        "name": "Cranial Nerve Disorders",
        "section": "Nervous System",
        "questionCount": 24
      },
      {
        "id": 473,
        "moduleId": "m62",
        "name": "Cerebrovascular Disease",
        "section": "Nervous System",
        "questionCount": 7
      },
      {
        "id": 474,
        "moduleId": "m63",
        "name": "Meningitis Encephalitis",
        "section": "Nervous System",
        "questionCount": 4
      },
      {
        "id": 475,
        "moduleId": "m64",
        "name": "Plasma Cell Disorders",
        "section": "Plasma Cell Disorders",
        "questionCount": 47
      },
      {
        "id": 476,
        "moduleId": "m65",
        "name": "Chronic Myeloid Leukemia and Lymphoid Leukemias",
        "section": "Chronic Myeloid Leukemia and Lymphoid Leukemias",
        "questionCount": 91
      },
      {
        "id": 477,
        "moduleId": "m66",
        "name": "HIV / AIDS - Epidemiology and Diagnosis",
        "section": "HIV / AIDS - Epidemiology and Diagnosis",
        "questionCount": 151
      },
      {
        "id": 478,
        "moduleId": "m67",
        "name": "HIV / AIDS - Investigations",
        "section": "HIV / AIDS - Investigations",
        "questionCount": 103
      },
      {
        "id": 479,
        "moduleId": "m68",
        "name": "Mixed / Miscellaneous Topics",
        "section": "COVID 19 - Investigations",
        "questionCount": 1
      }
    ]
  },
  {
    "subjectId": 1000120,
    "name": "Surgery",
    "questionCount": 2049,
    "moduleCount": 51,
    "modules": [
      {
        "id": 480,
        "moduleId": "m0",
        "name": "Fluids, Electrolytes & Nutrition",
        "section": "General Surgery",
        "questionCount": 26
      },
      {
        "id": 481,
        "moduleId": "m1",
        "name": "Shock and Blood Transfusion",
        "section": "General Surgery",
        "questionCount": 63
      },
      {
        "id": 482,
        "moduleId": "m2",
        "name": "Instruments & Sutures",
        "section": "General Surgery",
        "questionCount": 15
      },
      {
        "id": 483,
        "moduleId": "m3",
        "name": "Paediatric Surgery",
        "section": "General Surgery",
        "questionCount": 444
      },
      {
        "id": 484,
        "moduleId": "m4",
        "name": "Trauma - Scores, Investigations and Assessment",
        "section": "General Surgery",
        "questionCount": 25
      },
      {
        "id": 485,
        "moduleId": "m5",
        "name": "Trauma - Spinal, Thoracic and Abdominal Injuries",
        "section": "General Surgery",
        "questionCount": 102
      },
      {
        "id": 486,
        "moduleId": "m6",
        "name": "Breast - Anatomy, Congenital and Benign Diseases",
        "section": "Breast",
        "questionCount": 37
      },
      {
        "id": 487,
        "moduleId": "m7",
        "name": "Carcinoma Breast - Risk Factors and Types",
        "section": "Breast",
        "questionCount": 79
      },
      {
        "id": 488,
        "moduleId": "m8",
        "name": "Investigations in Breast diseases",
        "section": "Breast",
        "questionCount": 3
      },
      {
        "id": 489,
        "moduleId": "m9",
        "name": "Carcinoma Breast - Staging, Prognosis & Molecular Types",
        "section": "Breast",
        "questionCount": 30
      },
      {
        "id": 490,
        "moduleId": "m10",
        "name": "Carcinoma Breast - Treatment",
        "section": "Breast",
        "questionCount": 51
      },
      {
        "id": 491,
        "moduleId": "m11",
        "name": "Benign Lesions of Thyroid",
        "section": "Endocrine System",
        "questionCount": 38
      },
      {
        "id": 492,
        "moduleId": "m12",
        "name": "Thyroid Malignancies",
        "section": "Endocrine System",
        "questionCount": 9
      },
      {
        "id": 493,
        "moduleId": "m13",
        "name": "Esophagus - Congenital, Motility & Inflammatory Disorders",
        "section": "Upper GI Surgery",
        "questionCount": 45
      },
      {
        "id": 494,
        "moduleId": "m14",
        "name": "Esophagus - GERD & Carcinoma",
        "section": "Upper GI Surgery",
        "questionCount": 22
      },
      {
        "id": 495,
        "moduleId": "m15",
        "name": "Stomach and Duodenum",
        "section": "Upper GI Surgery",
        "questionCount": 25
      },
      {
        "id": 496,
        "moduleId": "m16",
        "name": "Carcinoma Stomach",
        "section": "Upper GI Surgery",
        "questionCount": 4
      },
      {
        "id": 497,
        "moduleId": "m17",
        "name": "Metabolic & Bariatric Surgery",
        "section": "Upper GI Surgery",
        "questionCount": 44
      },
      {
        "id": 498,
        "moduleId": "m18",
        "name": "Small Intestine",
        "section": "Lower GI & Hernia Surgery",
        "questionCount": 50
      },
      {
        "id": 499,
        "moduleId": "m19",
        "name": "Large Intestine",
        "section": "Lower GI & Hernia Surgery",
        "questionCount": 11
      },
      {
        "id": 500,
        "moduleId": "m20",
        "name": "Appendix",
        "section": "Lower GI & Hernia Surgery",
        "questionCount": 50
      },
      {
        "id": 501,
        "moduleId": "m21",
        "name": "Polyps and Colorectal Carcinoma",
        "section": "Lower GI & Hernia Surgery",
        "questionCount": 20
      },
      {
        "id": 502,
        "moduleId": "m22",
        "name": "Rectum",
        "section": "Lower GI & Hernia Surgery",
        "questionCount": 39
      },
      {
        "id": 503,
        "moduleId": "m23",
        "name": "Anus and Anal Canal",
        "section": "Lower GI & Hernia Surgery",
        "questionCount": 15
      },
      {
        "id": 504,
        "moduleId": "m24",
        "name": "Hernia",
        "section": "Lower GI & Hernia Surgery",
        "questionCount": 121
      },
      {
        "id": 505,
        "moduleId": "m25",
        "name": "Benign Conditions of Liver",
        "section": "Hepato Biliary Surgery",
        "questionCount": 25
      },
      {
        "id": 506,
        "moduleId": "m26",
        "name": "Benign Tumors of Liver",
        "section": "Hepato Biliary Surgery",
        "questionCount": 3
      },
      {
        "id": 507,
        "moduleId": "m27",
        "name": "Malignant Tumors of Liver",
        "section": "Hepato Biliary Surgery",
        "questionCount": 24
      },
      {
        "id": 508,
        "moduleId": "m28",
        "name": "Gall Bladder",
        "section": "Hepato Biliary Surgery",
        "questionCount": 43
      },
      {
        "id": 509,
        "moduleId": "m29",
        "name": "Bile Duct",
        "section": "Hepato Biliary Surgery",
        "questionCount": 56
      },
      {
        "id": 510,
        "moduleId": "m30",
        "name": "Spleen",
        "section": "Spleen & Pancreatic Surgery",
        "questionCount": 27
      },
      {
        "id": 511,
        "moduleId": "m31",
        "name": "Endocrine Pancreas",
        "section": "Spleen & Pancreatic Surgery",
        "questionCount": 40
      },
      {
        "id": 512,
        "moduleId": "m32",
        "name": "Congenital Anomalies and Acute Pancreatitis",
        "section": "Spleen & Pancreatic Surgery",
        "questionCount": 33
      },
      {
        "id": 513,
        "moduleId": "m33",
        "name": "Chronic Pancreatitis",
        "section": "Spleen & Pancreatic Surgery",
        "questionCount": 36
      },
      {
        "id": 514,
        "moduleId": "m34",
        "name": "Carcinoma Pancreas",
        "section": "Spleen & Pancreatic Surgery",
        "questionCount": 7
      },
      {
        "id": 515,
        "moduleId": "m35",
        "name": "Congenital Diseases of Kidney and Urinary Calculi",
        "section": "Urology",
        "questionCount": 23
      },
      {
        "id": 516,
        "moduleId": "m36",
        "name": "Infections and Tumors of Kidney",
        "section": "Urology",
        "questionCount": 9
      },
      {
        "id": 517,
        "moduleId": "m37",
        "name": "Urinary Bladder and Ureters",
        "section": "Urology",
        "questionCount": 28
      },
      {
        "id": 518,
        "moduleId": "m38",
        "name": "Prostate",
        "section": "Urology",
        "questionCount": 46
      },
      {
        "id": 519,
        "moduleId": "m39",
        "name": "Urethra and Penis",
        "section": "Urology",
        "questionCount": 19
      },
      {
        "id": 520,
        "moduleId": "m40",
        "name": "Testes and Scrotum",
        "section": "Urology",
        "questionCount": 17
      },
      {
        "id": 521,
        "moduleId": "m41",
        "name": "Head Injury",
        "section": "Neurosurgery",
        "questionCount": 35
      },
      {
        "id": 522,
        "moduleId": "m42",
        "name": "Oral Cavity & Salivary glands",
        "section": "Head and Neck",
        "questionCount": 23
      },
      {
        "id": 523,
        "moduleId": "m43",
        "name": "Burns",
        "section": "Plastic Surgery",
        "questionCount": 30
      },
      {
        "id": 524,
        "moduleId": "m44",
        "name": "Wound Healing, Tissue Repair and Scar",
        "section": "Plastic Surgery",
        "questionCount": 38
      },
      {
        "id": 525,
        "moduleId": "m45",
        "name": "Reconstructive Surgery",
        "section": "Plastic Surgery",
        "questionCount": 34
      },
      {
        "id": 526,
        "moduleId": "m46",
        "name": "Ischemic Arterial Diseases",
        "section": "Cardiothoracic & Vascular Surgery",
        "questionCount": 27
      },
      {
        "id": 527,
        "moduleId": "m47",
        "name": "Arterial Aneurysms, Dissections and Malformations",
        "section": "Cardiothoracic & Vascular Surgery",
        "questionCount": 9
      },
      {
        "id": 528,
        "moduleId": "m48",
        "name": "Venous Diseases",
        "section": "Cardiothoracic & Vascular Surgery",
        "questionCount": 12
      },
      {
        "id": 529,
        "moduleId": "m49",
        "name": "Skin Malignancies",
        "section": "Skin",
        "questionCount": 19
      },
      {
        "id": 530,
        "moduleId": "m50",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Skin",
        "questionCount": 18
      }
    ]
  },
  {
    "subjectId": 1000155,
    "name": "OB & G",
    "questionCount": 1805,
    "moduleCount": 44,
    "modules": [
      {
        "id": 531,
        "moduleId": "m0",
        "name": "Anatomy of Female Pelvic Organs",
        "section": "Fundamentals of Reproduction",
        "questionCount": 47
      },
      {
        "id": 532,
        "moduleId": "m1",
        "name": "The Physiology of Conception",
        "section": "Fundamentals of Reproduction",
        "questionCount": 4
      },
      {
        "id": 533,
        "moduleId": "m2",
        "name": "Maternal Pelvis and Fetal Skull",
        "section": "Fundamentals of Reproduction",
        "questionCount": 57
      },
      {
        "id": 534,
        "moduleId": "m3",
        "name": "Placenta and Fetal Membranes",
        "section": "Fundamentals of Reproduction",
        "questionCount": 60
      },
      {
        "id": 535,
        "moduleId": "m4",
        "name": "Sexual Development, Puberty and Adolescence",
        "section": "Fundamentals of Reproduction",
        "questionCount": 44
      },
      {
        "id": 536,
        "moduleId": "m5",
        "name": "Physiological Changes During Pregnancy",
        "section": "Normal Pregnancy and Antenatal Care",
        "questionCount": 239
      },
      {
        "id": 537,
        "moduleId": "m6",
        "name": "Diagnosis of Pregnancy and Antenatal Care",
        "section": "Normal Pregnancy and Antenatal Care",
        "questionCount": 136
      },
      {
        "id": 538,
        "moduleId": "m7",
        "name": "Antenatal Investigations",
        "section": "Normal Pregnancy and Antenatal Care",
        "questionCount": 5
      },
      {
        "id": 539,
        "moduleId": "m8",
        "name": "Obstetrical Imaging",
        "section": "Normal Pregnancy and Antenatal Care",
        "questionCount": 2
      },
      {
        "id": 540,
        "moduleId": "m9",
        "name": "Normal Labour",
        "section": "Labor and Puerperium",
        "questionCount": 25
      },
      {
        "id": 541,
        "moduleId": "m10",
        "name": "Abnormal Labour",
        "section": "Labor and Puerperium",
        "questionCount": 17
      },
      {
        "id": 542,
        "moduleId": "m11",
        "name": "Induction and Augmentation of Labour",
        "section": "Labor and Puerperium",
        "questionCount": 12
      },
      {
        "id": 543,
        "moduleId": "m12",
        "name": "Operative Vaginal Delivery",
        "section": "Labor and Puerperium",
        "questionCount": 128
      },
      {
        "id": 544,
        "moduleId": "m13",
        "name": "Caesarean Section and Vaginal Birth After Caesarean (VBAC)",
        "section": "Labor and Puerperium",
        "questionCount": 104
      },
      {
        "id": 545,
        "moduleId": "m14",
        "name": "Multifetal Pregnancy",
        "section": "Obstetric Complications",
        "questionCount": 14
      },
      {
        "id": 546,
        "moduleId": "m15",
        "name": "Ectopic Pregnancy",
        "section": "Obstetric Complications",
        "questionCount": 52
      },
      {
        "id": 547,
        "moduleId": "m16",
        "name": "Abortion and Medical Termination of Pregnancy",
        "section": "Obstetric Complications",
        "questionCount": 33
      },
      {
        "id": 548,
        "moduleId": "m17",
        "name": "Antepartum Hemorrhage",
        "section": "Obstetric Complications",
        "questionCount": 15
      },
      {
        "id": 549,
        "moduleId": "m18",
        "name": "Postpartum Haemorrhage",
        "section": "Obstetric Complications",
        "questionCount": 17
      },
      {
        "id": 550,
        "moduleId": "m19",
        "name": "Preterm Labor and Postterm Pregnancy",
        "section": "Obstetric Complications",
        "questionCount": 31
      },
      {
        "id": 551,
        "moduleId": "m20",
        "name": "Gestational Trophoblastic Diseases",
        "section": "Obstetric Complications",
        "questionCount": 13
      },
      {
        "id": 552,
        "moduleId": "m21",
        "name": "Anemia in Pregnancy",
        "section": "Medical and Surgical Complications in Pregnancy",
        "questionCount": 54
      },
      {
        "id": 553,
        "moduleId": "m22",
        "name": "Hypertensive Disorders in Pregnancy",
        "section": "Medical and Surgical Complications in Pregnancy",
        "questionCount": 15
      },
      {
        "id": 554,
        "moduleId": "m23",
        "name": "Diabetes in Pregnancy",
        "section": "Medical and Surgical Complications in Pregnancy",
        "questionCount": 14
      },
      {
        "id": 555,
        "moduleId": "m24",
        "name": "Cardiovascular Conditions in Pregnancy",
        "section": "Medical and Surgical Complications in Pregnancy",
        "questionCount": 32
      },
      {
        "id": 556,
        "moduleId": "m25",
        "name": "Rhesus Isoimmunization",
        "section": "Medical and Surgical Complications in Pregnancy",
        "questionCount": 2
      },
      {
        "id": 557,
        "moduleId": "m26",
        "name": "Hepatic Disorders and Infections in Pregnancy",
        "section": "Medical and Surgical Complications in Pregnancy",
        "questionCount": 11
      },
      {
        "id": 558,
        "moduleId": "m27",
        "name": "Disorders of Menstruation",
        "section": "General Gynaecology",
        "questionCount": 5
      },
      {
        "id": 559,
        "moduleId": "m28",
        "name": "Prolapse",
        "section": "General Gynaecology",
        "questionCount": 40
      },
      {
        "id": 560,
        "moduleId": "m29",
        "name": "Fibroid",
        "section": "General Gynaecology",
        "questionCount": 41
      },
      {
        "id": 561,
        "moduleId": "m30",
        "name": "Endometriosis and Adenomyosis",
        "section": "General Gynaecology",
        "questionCount": 12
      },
      {
        "id": 562,
        "moduleId": "m31",
        "name": "Disorders of Ovary",
        "section": "General Gynaecology",
        "questionCount": 14
      },
      {
        "id": 563,
        "moduleId": "m32",
        "name": "Contraception and Sterilization",
        "section": "General Gynaecology",
        "questionCount": 20
      },
      {
        "id": 564,
        "moduleId": "m33",
        "name": "Vaginal Infections",
        "section": "Gynaecologic Infections",
        "questionCount": 14
      },
      {
        "id": 565,
        "moduleId": "m34",
        "name": "Vulval Infections",
        "section": "Gynaecologic Infections",
        "questionCount": 2
      },
      {
        "id": 566,
        "moduleId": "m35",
        "name": "Pelvic Inflammatory Disease",
        "section": "Gynaecologic Infections",
        "questionCount": 33
      },
      {
        "id": 567,
        "moduleId": "m36",
        "name": "Genital Tuberculosis",
        "section": "Gynaecologic Infections",
        "questionCount": 27
      },
      {
        "id": 568,
        "moduleId": "m37",
        "name": "Infertility",
        "section": "Infertility and Menopause",
        "questionCount": 84
      },
      {
        "id": 569,
        "moduleId": "m38",
        "name": "Perimenopause, Menopause and Post-Menopausal Bleeding",
        "section": "Infertility and Menopause",
        "questionCount": 57
      },
      {
        "id": 570,
        "moduleId": "m39",
        "name": "Ovarian Tumors",
        "section": "Gynaecologic Oncology",
        "questionCount": 71
      },
      {
        "id": 571,
        "moduleId": "m40",
        "name": "Vulval & Vaginal Malignancy",
        "section": "Gynaecologic Oncology",
        "questionCount": 7
      },
      {
        "id": 572,
        "moduleId": "m41",
        "name": "Carcinoma Cervix",
        "section": "Gynaecologic Oncology",
        "questionCount": 54
      },
      {
        "id": 573,
        "moduleId": "m42",
        "name": "Carcinoma Endometrium",
        "section": "Gynaecologic Oncology",
        "questionCount": 13
      },
      {
        "id": 574,
        "moduleId": "m43",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Instruments",
        "questionCount": 128
      }
    ]
  },
  {
    "subjectId": 1000122,
    "name": "Pediatrics",
    "questionCount": 1274,
    "moduleCount": 34,
    "modules": [
      {
        "id": 575,
        "moduleId": "m0",
        "name": "Basics of Neonatology and Routine Newborn Care",
        "section": "Neonatology",
        "questionCount": 83
      },
      {
        "id": 576,
        "moduleId": "m1",
        "name": "Diseases in Neonates requiring Special Care",
        "section": "Neonatology",
        "questionCount": 47
      },
      {
        "id": 577,
        "moduleId": "m2",
        "name": "Apgar score and Neonatal Resuscitation",
        "section": "Neonatology",
        "questionCount": 44
      },
      {
        "id": 578,
        "moduleId": "m3",
        "name": "Developmental Milestones",
        "section": "Growth and Development",
        "questionCount": 39
      },
      {
        "id": 579,
        "moduleId": "m4",
        "name": "Facets of Growth and Development",
        "section": "Growth and Development",
        "questionCount": 98
      },
      {
        "id": 580,
        "moduleId": "m5",
        "name": "Nutrition and Breastfeeding",
        "section": "Nutrition",
        "questionCount": 38
      },
      {
        "id": 581,
        "moduleId": "m6",
        "name": "Protein Energy Malnutrition",
        "section": "Nutrition",
        "questionCount": 36
      },
      {
        "id": 582,
        "moduleId": "m7",
        "name": "Deficiency of Fat Soluble Vitamins",
        "section": "Nutrition",
        "questionCount": 41
      },
      {
        "id": 583,
        "moduleId": "m8",
        "name": "Deficiency of Water-soluble Vitamins & Trace Elements",
        "section": "Nutrition",
        "questionCount": 5
      },
      {
        "id": 584,
        "moduleId": "m9",
        "name": "Fluid and Electrolyte Disorders",
        "section": "Fluids and Electrolytes",
        "questionCount": 27
      },
      {
        "id": 585,
        "moduleId": "m10",
        "name": "Chromosomal Disorders",
        "section": "Genetic Disorders",
        "questionCount": 68
      },
      {
        "id": 586,
        "moduleId": "m11",
        "name": "Metabolic Disorders of Amino Acids",
        "section": "Metabolic Disorders",
        "questionCount": 39
      },
      {
        "id": 587,
        "moduleId": "m12",
        "name": "Metabolic Disorders of Urea Cycle, Complex Molecules, and Carbohydrates",
        "section": "Metabolic Disorders",
        "questionCount": 23
      },
      {
        "id": 588,
        "moduleId": "m13",
        "name": "Polio and AIDS",
        "section": "Childhood Infections",
        "questionCount": 2
      },
      {
        "id": 589,
        "moduleId": "m14",
        "name": "Paediatric Bacterial and Parasitic Infections",
        "section": "Childhood Infections",
        "questionCount": 50
      },
      {
        "id": 590,
        "moduleId": "m15",
        "name": "Measles, Mumps, Rubella and Other Viral Infections",
        "section": "Childhood Infections",
        "questionCount": 77
      },
      {
        "id": 591,
        "moduleId": "m16",
        "name": "Surgical GI Disorders",
        "section": "Gastrointestinal System",
        "questionCount": 20
      },
      {
        "id": 592,
        "moduleId": "m17",
        "name": "Medical GI Disorders",
        "section": "Gastrointestinal System",
        "questionCount": 5
      },
      {
        "id": 593,
        "moduleId": "m18",
        "name": "Disorders of the Liver",
        "section": "Gastrointestinal System",
        "questionCount": 15
      },
      {
        "id": 594,
        "moduleId": "m19",
        "name": "Neonatal Respiratory Disorders",
        "section": "Respiratory System",
        "questionCount": 93
      },
      {
        "id": 595,
        "moduleId": "m20",
        "name": "Childhood Respiratory Disorders",
        "section": "Respiratory System",
        "questionCount": 10
      },
      {
        "id": 596,
        "moduleId": "m21",
        "name": "Fetal Circulation",
        "section": "Cardiovascular System",
        "questionCount": 12
      },
      {
        "id": 597,
        "moduleId": "m22",
        "name": "Acyanotic Congenital Heart Diseases",
        "section": "Cardiovascular System",
        "questionCount": 51
      },
      {
        "id": 598,
        "moduleId": "m23",
        "name": "Cyanotic Congenital Heart Diseases",
        "section": "Cardiovascular System",
        "questionCount": 16
      },
      {
        "id": 599,
        "moduleId": "m24",
        "name": "Paediatric Nephrology",
        "section": "Genito-Urinary System",
        "questionCount": 12
      },
      {
        "id": 600,
        "moduleId": "m25",
        "name": "Disorders of Thyroid",
        "section": "Endocrine System",
        "questionCount": 4
      },
      {
        "id": 601,
        "moduleId": "m26",
        "name": "Congenital Adrenal Hyperplasia and Related Disorders",
        "section": "Endocrine System",
        "questionCount": 23
      },
      {
        "id": 602,
        "moduleId": "m27",
        "name": "Disorders of the Pituitary Gland",
        "section": "Endocrine System",
        "questionCount": 1
      },
      {
        "id": 603,
        "moduleId": "m28",
        "name": "Disorders of Puberty",
        "section": "Endocrine System",
        "questionCount": 3
      },
      {
        "id": 604,
        "moduleId": "m29",
        "name": "Solid Neoplasms of Childhood",
        "section": "Childhood Malignancies",
        "questionCount": 26
      },
      {
        "id": 605,
        "moduleId": "m30",
        "name": "Paediatric Rheumatology",
        "section": "Paediatric Rheumatology",
        "questionCount": 69
      },
      {
        "id": 606,
        "moduleId": "m31",
        "name": "Paediatric Hematology - Introduction, Bleeding, and Clotting Disorders",
        "section": "Hematology",
        "questionCount": 20
      },
      {
        "id": 607,
        "moduleId": "m32",
        "name": "Paediatric Anemias",
        "section": "Hematology",
        "questionCount": 1
      },
      {
        "id": 608,
        "moduleId": "m33",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Hematology",
        "questionCount": 176
      }
    ]
  },
  {
    "subjectId": 1000190,
    "name": "Anaesthesia",
    "questionCount": 1103,
    "moduleCount": 24,
    "modules": [
      {
        "id": 609,
        "moduleId": "m0",
        "name": "History and Ethical Aspects of Anaesthesia",
        "section": "Preoperative Evaluation and Monitoring",
        "questionCount": 16
      },
      {
        "id": 610,
        "moduleId": "m1",
        "name": "Preoperative Evaluation",
        "section": "Preoperative Evaluation and Monitoring",
        "questionCount": 23
      },
      {
        "id": 611,
        "moduleId": "m2",
        "name": "CNS and CVS Monitoring in Anaesthesia",
        "section": "Preoperative Evaluation and Monitoring",
        "questionCount": 30
      },
      {
        "id": 612,
        "moduleId": "m3",
        "name": "Respiratory Monitoring in Anaesthesia",
        "section": "Preoperative Evaluation and Monitoring",
        "questionCount": 29
      },
      {
        "id": 613,
        "moduleId": "m4",
        "name": "Airway Devices",
        "section": "Airway Management and Resuscitation",
        "questionCount": 46
      },
      {
        "id": 614,
        "moduleId": "m5",
        "name": "Intubation",
        "section": "Airway Management and Resuscitation",
        "questionCount": 95
      },
      {
        "id": 615,
        "moduleId": "m6",
        "name": "Breathing Systems",
        "section": "Airway Management and Resuscitation",
        "questionCount": 31
      },
      {
        "id": 616,
        "moduleId": "m7",
        "name": "Anaesthesia Workstation",
        "section": "Airway Management and Resuscitation",
        "questionCount": 12
      },
      {
        "id": 617,
        "moduleId": "m8",
        "name": "ACLS",
        "section": "Airway Management and Resuscitation",
        "questionCount": 8
      },
      {
        "id": 618,
        "moduleId": "m9",
        "name": "Ventilation and O2 Delivery Systems",
        "section": "Airway Management and Resuscitation",
        "questionCount": 62
      },
      {
        "id": 619,
        "moduleId": "m10",
        "name": "Depolarising Muscle Relaxants",
        "section": "Muscle Relaxants",
        "questionCount": 91
      },
      {
        "id": 620,
        "moduleId": "m11",
        "name": "Inhaled Anaesthetics - Properties, N2O and Halothane",
        "section": "General Anaesthesia",
        "questionCount": 47
      },
      {
        "id": 621,
        "moduleId": "m12",
        "name": "Inhaled Anaesthetics - Fluorinated Agents, Inert Agents and Therapeutic Gases",
        "section": "General Anaesthesia",
        "questionCount": 74
      },
      {
        "id": 622,
        "moduleId": "m13",
        "name": "Intravenous Anaesthesia - Barbiturates, Benzodiazepines & Propofol",
        "section": "General Anaesthesia",
        "questionCount": 134
      },
      {
        "id": 623,
        "moduleId": "m14",
        "name": "Intravenous Anaesthesia - Etomidate, Ketamine and Daycare Surgery",
        "section": "General Anaesthesia",
        "questionCount": 96
      },
      {
        "id": 624,
        "moduleId": "m15",
        "name": "Local Anaesthetics - General Properties",
        "section": "Local and Regional Anaesthesia",
        "questionCount": 142
      },
      {
        "id": 625,
        "moduleId": "m16",
        "name": "Local Anaesthetics - Specific Drugs",
        "section": "Local and Regional Anaesthesia",
        "questionCount": 37
      },
      {
        "id": 626,
        "moduleId": "m17",
        "name": "Regional Anaesthesia: Techniques",
        "section": "Local and Regional Anaesthesia",
        "questionCount": 20
      },
      {
        "id": 627,
        "moduleId": "m18",
        "name": "Regional Anaesthesia: Complications and Contraindications",
        "section": "Local and Regional Anaesthesia",
        "questionCount": 10
      },
      {
        "id": 628,
        "moduleId": "m19",
        "name": "Peripheral Nerve Blocks",
        "section": "Local and Regional Anaesthesia",
        "questionCount": 35
      },
      {
        "id": 629,
        "moduleId": "m20",
        "name": "Anaesthetic Implication of Concurrent Diseases",
        "section": "Anaesthesia in Specific Conditions",
        "questionCount": 23
      },
      {
        "id": 630,
        "moduleId": "m21",
        "name": "Paediatric and Obstetric Anaesthesia",
        "section": "Anaesthesia in Specific Conditions",
        "questionCount": 11
      },
      {
        "id": 631,
        "moduleId": "m22",
        "name": "Complications of Anaesthesia",
        "section": "Complications of Anaesthesia",
        "questionCount": 28
      },
      {
        "id": 632,
        "moduleId": "m23",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Complications of Anaesthesia",
        "questionCount": 3
      }
    ]
  },
  {
    "subjectId": 1000124,
    "name": "Dermatology",
    "questionCount": 836,
    "moduleCount": 24,
    "modules": [
      {
        "id": 633,
        "moduleId": "m0",
        "name": "Anatomy & Physiology of Skin",
        "section": "The Skin",
        "questionCount": 48
      },
      {
        "id": 634,
        "moduleId": "m1",
        "name": "Dermatopathology of Skin Lesions",
        "section": "Clinical Dermatology",
        "questionCount": 182
      },
      {
        "id": 635,
        "moduleId": "m2",
        "name": "Morphology and Investigations of Skin Lesions",
        "section": "Clinical Dermatology",
        "questionCount": 35
      },
      {
        "id": 636,
        "moduleId": "m3",
        "name": "Acne, Rosacea and Others",
        "section": "Adnexa and Appendages",
        "questionCount": 9
      },
      {
        "id": 637,
        "moduleId": "m4",
        "name": "Disorders of Hair and Nails",
        "section": "Hair and Nails",
        "questionCount": 39
      },
      {
        "id": 638,
        "moduleId": "m5",
        "name": "Disorders of Skin Pigmentation",
        "section": "Skin Pigmentation",
        "questionCount": 44
      },
      {
        "id": 639,
        "moduleId": "m6",
        "name": "Dermatitis",
        "section": "Allergic Disorders & Dermatitis",
        "questionCount": 99
      },
      {
        "id": 640,
        "moduleId": "m7",
        "name": "Urticaria & Angioedema",
        "section": "Allergic Disorders & Dermatitis",
        "questionCount": 12
      },
      {
        "id": 641,
        "moduleId": "m8",
        "name": "Reactive Skin Diseases and Drug Eruptions",
        "section": "Allergic Disorders & Dermatitis",
        "questionCount": 9
      },
      {
        "id": 642,
        "moduleId": "m9",
        "name": "Papulosquamous Disorders",
        "section": "Papulosquamous Disorders",
        "questionCount": 9
      },
      {
        "id": 643,
        "moduleId": "m10",
        "name": "Psoriasis",
        "section": "Papulosquamous Disorders",
        "questionCount": 77
      },
      {
        "id": 644,
        "moduleId": "m11",
        "name": "Vesiculobullous Diseases",
        "section": "Vesiculobullous Disorders",
        "questionCount": 27
      },
      {
        "id": 645,
        "moduleId": "m12",
        "name": "Mycobacterial Infections",
        "section": "Skin Infections & Infestations",
        "questionCount": 36
      },
      {
        "id": 646,
        "moduleId": "m13",
        "name": "Bacterial Infections",
        "section": "Skin Infections & Infestations",
        "questionCount": 24
      },
      {
        "id": 647,
        "moduleId": "m14",
        "name": "Viral Infections",
        "section": "Skin Infections & Infestations",
        "questionCount": 14
      },
      {
        "id": 648,
        "moduleId": "m15",
        "name": "Fungal and Protozoal Infections",
        "section": "Skin Infections & Infestations",
        "questionCount": 19
      },
      {
        "id": 649,
        "moduleId": "m16",
        "name": "Arthropod and Parasitic Infections",
        "section": "Skin Infections & Infestations",
        "questionCount": 5
      },
      {
        "id": 650,
        "moduleId": "m17",
        "name": "Syphilis",
        "section": "Sexually Transmitted Infections",
        "questionCount": 37
      },
      {
        "id": 651,
        "moduleId": "m18",
        "name": "Non Syphilitic Sexually Transmitted Diseases",
        "section": "Sexually Transmitted Infections",
        "questionCount": 20
      },
      {
        "id": 652,
        "moduleId": "m19",
        "name": "Genodermatoses & Nutritional Disorders",
        "section": "Genodermatoses & Nutritional Disorders",
        "questionCount": 7
      },
      {
        "id": 653,
        "moduleId": "m20",
        "name": "Connective Tissue Disorders",
        "section": "Connective Tissue Disorders",
        "questionCount": 14
      },
      {
        "id": 654,
        "moduleId": "m21",
        "name": "Skin Malignancies",
        "section": "Skin Malignancies",
        "questionCount": 18
      },
      {
        "id": 655,
        "moduleId": "m22",
        "name": "Systemic Diseases and Skin",
        "section": "Skin in Systemic Disorders",
        "questionCount": 39
      },
      {
        "id": 656,
        "moduleId": "m23",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Skin in Systemic Disorders",
        "questionCount": 13
      }
    ]
  },
  {
    "subjectId": 1000141,
    "name": "Orthopaedics",
    "questionCount": 1360,
    "moduleCount": 30,
    "modules": [
      {
        "id": 657,
        "moduleId": "m0",
        "name": "Basics of Fracture and its Management",
        "section": "Fracture and its Complications",
        "questionCount": 380
      },
      {
        "id": 658,
        "moduleId": "m1",
        "name": "Complications of Fracture",
        "section": "Fracture and its Complications",
        "questionCount": 49
      },
      {
        "id": 659,
        "moduleId": "m2",
        "name": "Regional Conditions of Neck",
        "section": "Neck",
        "questionCount": 10
      },
      {
        "id": 660,
        "moduleId": "m3",
        "name": "Injuries of Clavicle, Shoulder and Arm",
        "section": "Upper Limb",
        "questionCount": 43
      },
      {
        "id": 661,
        "moduleId": "m4",
        "name": "Injuries of Elbow and Forearm",
        "section": "Upper Limb",
        "questionCount": 24
      },
      {
        "id": 662,
        "moduleId": "m5",
        "name": "Injuries of Hand",
        "section": "Upper Limb",
        "questionCount": 10
      },
      {
        "id": 663,
        "moduleId": "m6",
        "name": "Regional Conditions of the Upper Limb",
        "section": "Upper Limb",
        "questionCount": 31
      },
      {
        "id": 664,
        "moduleId": "m7",
        "name": "Dislocations of the Hip Joint",
        "section": "Lower Limb",
        "questionCount": 11
      },
      {
        "id": 665,
        "moduleId": "m8",
        "name": "Fractures of Femur",
        "section": "Lower Limb",
        "questionCount": 8
      },
      {
        "id": 666,
        "moduleId": "m9",
        "name": "Injuries of Knee, Leg and Foot",
        "section": "Lower Limb",
        "questionCount": 39
      },
      {
        "id": 667,
        "moduleId": "m10",
        "name": "AVN and Regional Conditions of Lower Limb",
        "section": "Lower Limb",
        "questionCount": 27
      },
      {
        "id": 668,
        "moduleId": "m11",
        "name": "Injuries of Spine",
        "section": "Spine & Pelvis",
        "questionCount": 28
      },
      {
        "id": 669,
        "moduleId": "m12",
        "name": "Regional Conditions of Spine",
        "section": "Spine & Pelvis",
        "questionCount": 3
      },
      {
        "id": 670,
        "moduleId": "m13",
        "name": "Spondylolisthesis & IVDP",
        "section": "Spine & Pelvis",
        "questionCount": 9
      },
      {
        "id": 671,
        "moduleId": "m14",
        "name": "Injuries of Pelvis",
        "section": "Spine & Pelvis",
        "questionCount": 3
      },
      {
        "id": 672,
        "moduleId": "m15",
        "name": "Infections of the Bone",
        "section": "Bone and Joint Infections",
        "questionCount": 64
      },
      {
        "id": 673,
        "moduleId": "m16",
        "name": "Skeletal Tuberculosis",
        "section": "Bone and Joint Infections",
        "questionCount": 12
      },
      {
        "id": 674,
        "moduleId": "m17",
        "name": "Fractures in Children",
        "section": "Paediatric Orthopaedics",
        "questionCount": 40
      },
      {
        "id": 675,
        "moduleId": "m18",
        "name": "CTEV, Genu Varum and Valgum",
        "section": "Paediatric Orthopaedics",
        "questionCount": 19
      },
      {
        "id": 676,
        "moduleId": "m19",
        "name": "Congenital Malformations, Perthes Disease and SCFE",
        "section": "Paediatric Orthopaedics",
        "questionCount": 60
      },
      {
        "id": 677,
        "moduleId": "m20",
        "name": "Metabolic Bone Diseases in Children",
        "section": "Metabolic Bone Diseases",
        "questionCount": 24
      },
      {
        "id": 678,
        "moduleId": "m21",
        "name": "Osteoporosis and Osteomalacia",
        "section": "Metabolic Bone Diseases",
        "questionCount": 34
      },
      {
        "id": 679,
        "moduleId": "m22",
        "name": "Paget's Disease and Hyperparathyroidism",
        "section": "Metabolic Bone Diseases",
        "questionCount": 27
      },
      {
        "id": 680,
        "moduleId": "m23",
        "name": "Rheumatoid Arthritis and Osteoarthritis",
        "section": "Arthritis & Other Joint Disorders",
        "questionCount": 140
      },
      {
        "id": 681,
        "moduleId": "m24",
        "name": "Nerve Injuries",
        "section": "Nerve Injuries",
        "questionCount": 111
      },
      {
        "id": 682,
        "moduleId": "m25",
        "name": "Benign Tumors Of Bone",
        "section": "Bone Tumors",
        "questionCount": 35
      },
      {
        "id": 683,
        "moduleId": "m26",
        "name": "Malignant Tumors of Bone",
        "section": "Bone Tumors",
        "questionCount": 35
      },
      {
        "id": 684,
        "moduleId": "m27",
        "name": "Trauma Amputations, Prosthetics and Joint Replacement Surgery",
        "section": "Advanced Orthopaedics & Management",
        "questionCount": 40
      },
      {
        "id": 685,
        "moduleId": "m28",
        "name": "Sports Injury",
        "section": "Advanced Orthopaedics & Management",
        "questionCount": 24
      },
      {
        "id": 686,
        "moduleId": "m29",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Advanced Orthopaedics & Management",
        "questionCount": 20
      }
    ]
  },
  {
    "subjectId": 1000161,
    "name": "Psychiatry",
    "questionCount": 926,
    "moduleCount": 33,
    "modules": [
      {
        "id": 687,
        "moduleId": "m0",
        "name": "Theories of Personality & Defense Mechanisms",
        "section": "Facets of Psychiatry",
        "questionCount": 12
      },
      {
        "id": 688,
        "moduleId": "m1",
        "name": "Symptoms and Clinical Manifestations in Psychiatry",
        "section": "Clinical Psychiatry",
        "questionCount": 178
      },
      {
        "id": 689,
        "moduleId": "m2",
        "name": "Assessment in Psychiatry",
        "section": "Clinical Psychiatry",
        "questionCount": 4
      },
      {
        "id": 690,
        "moduleId": "m3",
        "name": "Specific Treatment Modalities",
        "section": "Clinical Psychiatry",
        "questionCount": 32
      },
      {
        "id": 691,
        "moduleId": "m4",
        "name": "Neuropsychiatric Aspects of Systemic Disorders",
        "section": "Neuropsychiatry",
        "questionCount": 0
      },
      {
        "id": 692,
        "moduleId": "m5",
        "name": "Schizophrenia",
        "section": "Psychotic Disorders",
        "questionCount": 92
      },
      {
        "id": 693,
        "moduleId": "m6",
        "name": "Other Psychotic Disorders",
        "section": "Psychotic Disorders",
        "questionCount": 50
      },
      {
        "id": 694,
        "moduleId": "m7",
        "name": "Delirium",
        "section": "Neurocognitive Disorders",
        "questionCount": 35
      },
      {
        "id": 695,
        "moduleId": "m8",
        "name": "Dementia",
        "section": "Neurocognitive Disorders",
        "questionCount": 14
      },
      {
        "id": 696,
        "moduleId": "m9",
        "name": "Amnestic Disorders and Other Neurocognitive Disorders",
        "section": "Neurocognitive Disorders",
        "questionCount": 33
      },
      {
        "id": 697,
        "moduleId": "m10",
        "name": "Depressive Disorders",
        "section": "Mood Disorders",
        "questionCount": 18
      },
      {
        "id": 698,
        "moduleId": "m11",
        "name": "Bipolar and Related Disorders",
        "section": "Mood Disorders",
        "questionCount": 10
      },
      {
        "id": 699,
        "moduleId": "m12",
        "name": "Alcohol-Related Disorders",
        "section": "Substance-Related Disorders",
        "questionCount": 55
      },
      {
        "id": 700,
        "moduleId": "m13",
        "name": "Other Substance Use Disorders",
        "section": "Substance-Related Disorders",
        "questionCount": 43
      },
      {
        "id": 701,
        "moduleId": "m14",
        "name": "Anxiety Disorders",
        "section": "Neurosis",
        "questionCount": 22
      },
      {
        "id": 702,
        "moduleId": "m15",
        "name": "Obsessive-Compulsive and Related Disorders",
        "section": "Neurosis",
        "questionCount": 9
      },
      {
        "id": 703,
        "moduleId": "m16",
        "name": "Trauma and Stress-Related Disorders",
        "section": "Neurosis",
        "questionCount": 3
      },
      {
        "id": 704,
        "moduleId": "m17",
        "name": "Personality Disorders",
        "section": "Personality Disorders",
        "questionCount": 38
      },
      {
        "id": 705,
        "moduleId": "m18",
        "name": "Somatoform Disorders",
        "section": "Specific Psychiatric Conditions",
        "questionCount": 3
      },
      {
        "id": 706,
        "moduleId": "m19",
        "name": "Factitious Disorders, Malingering and Criminality",
        "section": "Specific Psychiatric Conditions",
        "questionCount": 2
      },
      {
        "id": 707,
        "moduleId": "m20",
        "name": "Dissociative Disorders",
        "section": "Specific Psychiatric Conditions",
        "questionCount": 12
      },
      {
        "id": 708,
        "moduleId": "m21",
        "name": "Sleep Disorders",
        "section": "Specific Psychiatric Conditions",
        "questionCount": 10
      },
      {
        "id": 709,
        "moduleId": "m22",
        "name": "Eating Disorders",
        "section": "Specific Psychiatric Conditions",
        "questionCount": 7
      },
      {
        "id": 710,
        "moduleId": "m23",
        "name": "Impulse-Control Disorders",
        "section": "Specific Psychiatric Conditions",
        "questionCount": 9
      },
      {
        "id": 711,
        "moduleId": "m24",
        "name": "Psychiatric Emergencies",
        "section": "Psychiatric Emergencies",
        "questionCount": 34
      },
      {
        "id": 712,
        "moduleId": "m25",
        "name": "Normal Sexuality and Sexual Dysfunction",
        "section": "Sexuality",
        "questionCount": 9
      },
      {
        "id": 713,
        "moduleId": "m26",
        "name": "Sexual Disorders and Sexual Abuse",
        "section": "Sexuality",
        "questionCount": 20
      },
      {
        "id": 714,
        "moduleId": "m27",
        "name": "Intellectual Disability & Specific Learning Disorders",
        "section": "Child Psychiatry",
        "questionCount": 34
      },
      {
        "id": 715,
        "moduleId": "m28",
        "name": "Autism Spectrum Disorder",
        "section": "Child Psychiatry",
        "questionCount": 51
      },
      {
        "id": 716,
        "moduleId": "m29",
        "name": "Attention-Deficit Disorders and Disruptive Behaviour",
        "section": "Child Psychiatry",
        "questionCount": 30
      },
      {
        "id": 717,
        "moduleId": "m30",
        "name": "Special Areas of Childhood Mental Health",
        "section": "Child Psychiatry",
        "questionCount": 20
      },
      {
        "id": 718,
        "moduleId": "m31",
        "name": "Forensic Psychiatry",
        "section": "Forensic Psychiatry",
        "questionCount": 3
      },
      {
        "id": 719,
        "moduleId": "m32",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Forensic Psychiatry",
        "questionCount": 34
      }
    ]
  },
  {
    "subjectId": 1000127,
    "name": "Radiology",
    "questionCount": 1184,
    "moduleCount": 20,
    "modules": [
      {
        "id": 720,
        "moduleId": "m0",
        "name": "Fundamentals of Imaging",
        "section": "Fundamentals of Radiology",
        "questionCount": 51
      },
      {
        "id": 721,
        "moduleId": "m1",
        "name": "Radiation - Exposure and Protection",
        "section": "Fundamentals of Radiology",
        "questionCount": 61
      },
      {
        "id": 722,
        "moduleId": "m2",
        "name": "Contrast Media and Patient Preparation",
        "section": "Fundamentals of Radiology",
        "questionCount": 321
      },
      {
        "id": 723,
        "moduleId": "m3",
        "name": "Imaging Modalities - Identification",
        "section": "Fundamentals of Radiology",
        "questionCount": 16
      },
      {
        "id": 724,
        "moduleId": "m4",
        "name": "Basics of Chest Imaging",
        "section": "Diagnostic Radiology",
        "questionCount": 129
      },
      {
        "id": 725,
        "moduleId": "m5",
        "name": "Chest Imaging - Lung Diseases",
        "section": "Diagnostic Radiology",
        "questionCount": 43
      },
      {
        "id": 726,
        "moduleId": "m6",
        "name": "Chest Imaging - Pleural and Mediastinal Conditions",
        "section": "Diagnostic Radiology",
        "questionCount": 75
      },
      {
        "id": 727,
        "moduleId": "m7",
        "name": "Neuroimaging - Neurovascular Disorders, Trauma & CT Brain",
        "section": "Diagnostic Radiology",
        "questionCount": 35
      },
      {
        "id": 728,
        "moduleId": "m8",
        "name": "Neuroimaging - CNS Tumors, Infections & Neurocutaneous Syndromes",
        "section": "Diagnostic Radiology",
        "questionCount": 18
      },
      {
        "id": 729,
        "moduleId": "m9",
        "name": "Neuroimaging - MRI Brain in Neurodegenerative & Other CNS Disorders",
        "section": "Diagnostic Radiology",
        "questionCount": 44
      },
      {
        "id": 730,
        "moduleId": "m10",
        "name": "Head and Neck Imaging",
        "section": "Diagnostic Radiology",
        "questionCount": 51
      },
      {
        "id": 731,
        "moduleId": "m11",
        "name": "GI Imaging - Upper GI Disorders & Pneumoperitoneum",
        "section": "Diagnostic Radiology",
        "questionCount": 22
      },
      {
        "id": 732,
        "moduleId": "m12",
        "name": "GI Imaging - Lower GI Disorders",
        "section": "Diagnostic Radiology",
        "questionCount": 17
      },
      {
        "id": 733,
        "moduleId": "m13",
        "name": "Hepatobiliary and Pancreatic Imaging",
        "section": "Diagnostic Radiology",
        "questionCount": 10
      },
      {
        "id": 734,
        "moduleId": "m14",
        "name": "Renal Imaging",
        "section": "Diagnostic Radiology",
        "questionCount": 28
      },
      {
        "id": 735,
        "moduleId": "m15",
        "name": "Women's Imaging",
        "section": "Diagnostic Radiology",
        "questionCount": 5
      },
      {
        "id": 736,
        "moduleId": "m16",
        "name": "Musculoskeletal Imaging",
        "section": "Diagnostic Radiology",
        "questionCount": 8
      },
      {
        "id": 737,
        "moduleId": "m17",
        "name": "Radiotherapy",
        "section": "Radionuclide Imaging and Radiation Oncology",
        "questionCount": 45
      },
      {
        "id": 738,
        "moduleId": "m18",
        "name": "Emergency and Interventional Radiology",
        "section": "Emergency and Interventional Radiology",
        "questionCount": 61
      },
      {
        "id": 739,
        "moduleId": "m19",
        "name": "Mixed / Miscellaneous Topics",
        "section": "Emergency and Interventional Radiology",
        "questionCount": 144
      }
    ]
  }
];
